/*************************************************************************************************
 *   003_getfacility.js
 *
 *   Get Facility
 *   API fetch all facilities (List Clinics) 
 *
 *   http://sgiman.com.ua/openemr/api/getfacility.php?token=df19b7027c8cab07db1e9eef0566e1c9
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'OpenEMR all facilities - <font size="6" color="red">tEMed</font>'; 

$(document).ready( function () 
{ 
  
  
  // TITLE TEST
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

  // XML REQUEST
  $('#XML').html('<a href="' + server + '/openemr/api/getfacility.php?token=' + key + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');

  facilityData();
  fetch();

});

/////////////////////////////////////// 
//           Get Facilities
///////////////////////////////////////

function fetch() {
    setTimeout ( function() 
    {
      facilityData();
      fetch();
    }, timeout);
}


function facilityData () 
{
    $.ajax ({
  
    url: server + "/openemr/api/getfacility.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();     
       
      // Status Reason
      $(data).find("facilities").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("facility").each ( function() {
      
      var info = 
      '<h3 id="title">Facility: ' + '<font size=5>' + $(this).find("name").text() + '</font></h3>' + 
      '<li><b>ID:</b> ' + $(this).find("id").text() + '</li>' +
      '<li><b>Phone:</b> ' + $(this).find("phone").text() + '</li>' +
      '<li><b>Fax:</b> ' + $(this).find("fax").text() + '</li>' +
      '<li><b>Street:</b> ' + $(this).find("street").text() + '</li>' +
      '<li><b>City:</b> ' + $(this).find("city").text() + '</li>' +
      '<li><b>State:</b> ' + $(this).find("state").text() + '</li>' +
      '<li><b>Postal Code:</b> ' + $(this).find("postal_code").text() + '</li>' +
      '<li><b>Country Code:</b> ' + $(this).find("country_code").text() + '</li>' +
      '<li><b>Federal EIN:</b> ' + $(this).find("federal_ein").text() + '</li>' +
      '<li><b>Website:</b> ' + $(this).find("website").text() + '</li>' +
      '<li><b>Email:</b> ' + $(this).find("email").text() + '</li>' +
      '<li><b>Facility NPI:</b> ' + $(this).find("facility_npi").text() + '</li>' +
      '<li><b>TAX ID TYPE:</b> ' + $(this).find("tax_id_type").text() + '</li>' + '<hr><br>'
         
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError)
     {
      alert(xhr.status);
      alert(thrownError);
     }

  })


}


