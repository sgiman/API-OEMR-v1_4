/*************************************************************************************************
 *   018_getreviewofsystemssummary.js
 *
 *   Get Review of Systems Summary
 *   API is allowed to get patient review of systems summary
 *
 *   http://sgiman.com.ua/openemr/api/getreviewofsystemssummary.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
      {

        // Remove elements 
        if ($(this) != '') $("#PID").children().remove();   

        // PATIENTS (Select:Options)
        $("#PID").append('<option selected value="0">NONE</option>');
        $(data).find("Patient").each( function() 
        {
          var pat =
          '<option value="' + $(this).find("pid").text() + '">' + 
          $(this).find("firstname").text() + ' ' +  $(this).find("lastname").text() + 
          ' (' +  $(this).find("pid").text() + ')</option>'; 
    
          $("#PID").append(pat);
   
        })

      }

    })   

});


/////////////////////////////////////// 
//           Patient Select
///////////////////////////////////////

function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getreviewofsystemssummary.php?token=' + key + 
  '&patientId=' + g_pid + '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  reviewofsystemsumData(g_pid, g_txt);
  fetch(g_pid, g_txt);
 
}


/////////////////////////////////////// 
//   Get Review of Systems Summary
///////////////////////////////////////

function fetch(pid) {
    setTimeout ( function(pid, txt) 
    {
      reviewofsystemsumData(pid, txt);
      fetch(pid, txt);
    }, timeout);
}


function reviewofsystemsumData (pid, txt) 
{

    // 1. AJAX - Review of Systems Summary (ROS)

    $.ajax ({
  
    url: server + "/openemr/api/getreviewofsystemssummary.php?token=" + key + "&patientId=" + pid,
    
    dataType: "xml",
    type: "GET",
    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("reviewofsystems").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("reviewofsystem").each ( function() {     
 
        var info =
        
        '<br><h3 id="title">' + txt + '&nbsp; &nbsp;ID: ' +  $(this).find("id").text() + '</h3>' +
        '<li><b>Date:</b> ' +  $(this).find("date").text() + '</li></br>';   
        $("#OEMR").append(info);

        $(this).find("disease").each ( function() {   
        var info =
       '<li><b>' + ROS_translate ($(this).find("name").text()) + '</b>  -  <span class="BlackText">'  +   $(this).find("status").text() + '</span></li><hr>';   
        
        if ($(this).find("status").text() == "YES" || $(this).find("status").text() == "NO" )
        $("#OEMR").append(info);

        })
 
      });
 
     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })

}

/**********************************************************************************
                                  ROS TRANSLATE
***********************************************************************************/
function  ROS_translate (s)
{

switch (s) 
{

/*----------------------------------------------------------------------------------
                              Review Of Systems (ROS)
-----------------------------------------------------------------------------------*/ 
// General             
    case 'fever':         return ('<span class="BlueText">Fever - ROS/General</span>');
                          break; 
   
    case 'chills':        return ('<span class="BlueText">Chills - ROS/General</span>'); 
                          break; 
    
    case 'night_sweats':  return ('<span class="BlueText">Night Sweats - ROS/General</span>'); 
                          break; 
    
    case 'weight_loss':   return ('<span class="BlueText">Weight Loss - ROS/General</span>'); 
                          break; 
    
    case 'poor_appetite': return ('<span class="BlueText">Poor Appetite - ROS/General</span>'); 
                          break; 
    
    case 'insomnia':      return ('<span class="BlueText">Insomnia - ROS/General</span>'); 
                          break; 
    
    case 'fatigued':      return ('<span class="BlueText">Fatigued - ROS/General</span>'); 
                          break; 
    
    case 'depressed':     return ('<span class="BlueText">Depressed - ROS/General</span>'); 
                          break; 
    
    case 'hyperactive':   return ('<span class="BlueText">Hyperactive - ROS/General</span>'); 
                          break; 
    
    case 'exposure_to_foreign_countries':  return ('<span class="BlueText">Exposure to Foreign Countries - ROS/General</span>'); 
                                            break; 
 

// Skin (ROS)  
case 'rashes':  return ('<span class="BlueText">Rashes - ROS/Skin</span>'); 
               break; 
case 'infections':  return ('<span class="BlueText">Infections - ROS/Skin</span>'); 
               break; 
case 'ulcerations':  return ('<span class="BlueText">Ulcerations - ROS/Skin</span>'); 
               break; 
case 'pemphigus':  return ('<span class="BlueText">Pemphigus - ROS/Skin</span>'); 
               break; 
case 'herpes':  return ('<span class="BlueText">Herpes - ROS/Skin</span>'); 
               break; 


//HEENT (ROS)
case 'cataracts':  return ('<span class="BlueText">Cataracts - ROS/HEENT</span>');
               break; 
case 'cataract_surgery':  return ('<span class="BlueText">Cataract Surgery - ROS/HEENT</span>'); 
               break; 
case 'glaucoma':  return ('<span class="BlueText">Glaucoma - ROS/HEENT</span>'); 
               break; 
case 'double_vision':  return ('<span class="BlueText">Double Vision - ROS/HEENT</span>'); 
               break; 
case 'blurred_vision':  return ('<span class="BlueText">Blurred Vision - ROS/HEENT</span>'); 
               break; 
case 'poor_hearing':  return ('<span class="BlueText">Poor Hearing - ROS/HEENT</span>'); 
               break; 
case 'headaches':  return ('<span class="BlueText">Headaches - ROS/HEENT</span>'); 
               break; 
case 'ringing_in_ears':  return ('<span class="BlueText">Ringing in Ears - ROS/HEENT</span>'); 
               break; 
case 'bloody_nose':  return ('<span class="BlueText">Bloody Nose - ROS/HEENT</span>'); 
               break; 
case 'sinusitis':  return ('<span class="BlueText">Sinusitis - ROS/HEENT</span>'); 
               break; 
case 'sinus_surgery':  return ('<span class="BlueText">Sinus Surgery - ROS/HEENT</span>'); 
               break; 
case 'dry_mouth':  return ('<span class="BlueText">Dry Mouth - ROS/HEENT</span>'); 
               break; 
case 'strep_throat':  return ('<span class="BlueText">Strep Throat - ROS/HEENT</span>'); 
               break; 
case 'tonsillectomy':  return ('<span class="BlueText">Tonsillectomy - ROS/HEENT</span>'); 
               break; 
case 'swollen_lymph_nodes':  return ('<span class="BlueText">Swollen Lymph Nodes - ROS/HEENT</span>'); 
               break; 
case 'throat_cancer':  return ('<span class="BlueText">Throat Cancer - ROS/HEENT</span>'); 
               break; 
case 'throat_cancer_surgery':  return ('<span class="BlueText">Throat Cancer Surgery - ROS/HEENT</span>'); 
               break; 


//Cardiovascular(ROS) 
case 'heart_attack':  return ('<span class="BlueText">Heart Attack - ROS/Cardiovascular</span>'); 
               break; 
case 'irregular_heart_beat':  return ('<span class="BlueText">Irregular Heart Beat - ROS/Cardiovascular</span>'); 
               break; 
case 'chest_pains':  return ('<span class="BlueText">Chest Pains - ROS/Cardiovascular</span>'); 
               break; 
case 'shortness_of_breath':  return ('<span class="BlueText">Shortness of Breath - ROS/Cardiovascular</span>'); 
               break; 
case 'high_blood_pressure':  return ('<span class="BlueText">High Blood Pressure - ROS/Cardiovascular</span>'); 
               break; 
case 'heart_failure':  return ('<span class="BlueText">Heart Failure - ROS/Cardiovascular</span>'); 
               break; 
case 'poor_circulation':  return ('<span class="BlueText">Poor Circulation - ROS/Cardiovascular</span>'); 
               break; 
case 'vascular_surgery':  return ('<span class="BlueText">Vascular Surgery - ROS/Cardiovascular</span>'); 
               break; 
case 'cardiac_catheterization':  return ('<span class="BlueText">Cardiac Catheterization - ROS/Cardiovascular</span>'); 
               break; 
case 'coronary_artery_bypass':  return ('<span class="BlueText">Coronary Artery Bypass - ROS/Cardiovascular</span>'); 
               break; 
case 'heart_transplant':  return ('<span class="BlueText">Heart Transplant - ROS/Cardiovascular</span>'); 
               break; 
case 'stress_test':  return ('<span class="BlueText">Stress Test - ROS/Cardiovascular</span>'); 
               break; 

// Endocrine (ROS) 
case 'insulin_dependent_diabetes':  return ('<span class="BlueText">Insulin Dependent Diabetes - ROS/Endocrine</span>'); 
               break; 
case 'noninsulin_dependent_diabetes':  return ('Non-Insulin Dependent Diabetes - ROS/Endocrine</span>'); 
               break; 
case 'hypothyroidism':  return ('<span class="BlueText">Hypothyroidism - ROS/Endocrine</span>'); 
               break; 
case 'hyperthyroidism':  return ('<span class="BlueText">Hyperthyroidism - ROS/Endocrine</span>'); 
               break; 
case 'cushing_syndrom':  return ('<span class="BlueText">Cushing Syndrome - ROS/Endocrine</span>'); 
               break; 
case 'addison_syndrom':  return ('<span class="BlueText">Addison Syndrome - ROS/Endocrine</span>'); 
               break; 

//Pulmonary (ROS) 
case 'emphysema':  return ('<span class="BlueText">Emphysema - ROS/Pulmonary</span>'); 
               break; 
case 'chronic_bronchitis':  return ('<span class="BlueText">Chronic Bronchitis - ROS/Pulmonary</span>'); 
               break; 
case 'interstitial_lung_disease':  return ('<span class="BlueText">Interstitial Lung Disease - ROS/Pulmonary</span>'); 
               break; 
case 'shortness_of_breath_2':  return ('<span class="BlueText">Shortness of Breath - ROS/Pulmonary</span>'); 
               break; 
case 'lung_cancer':  return ('<span class="BlueText">Lung Cancer - ROS/Pulmonary</span>'); 
               break; 
case 'lung_cancer_surgery':  return ('<span class="BlueText">Lung Cancer Surgery - ROS/Pulmonary</span>'); 
               break; 
case 'pheumothorax':  return ('<span class="BlueText">Pheumothorax - ROS/Pulmonary</span>'); 
               break; 

//Genitourinary (ROS) 
case 'kidney_failure':  return ('<span class="BlueText">Kidney Failure - ROS/Genitourinary</span>'); 
               break; 
case 'kidney_stones':  return ('<span class="BlueText">Kidney Stones - ROS/Genitourinary</span>'); 
               break; 
case 'kidney_cancer':  return ('<span class="BlueText">Kidney Cancer - ROS/Genitourinary</span>'); 
               break; 
case 'kidney_infections':  return ('<span class="BlueText">Kidney Infections - ROS/Genitourinary</span>');
               break; 
case 'bladder_infections':  return ('<span class="BlueText">Bladder Infections - ROS/Genitourinary</span>'); 
               break; 
case 'bladder_cancer':  return ('<span class="BlueText">Bladder Cancer - ROS/Genitourinary</span>'); 
               break; 
case 'prostate_problems':  return ('<span class="BlueText">Prostate Problems - ROS/Genitourinary</span>'); 
               break; 
case 'prostate_cancer':  return ('<span class="BlueText">Prostate Cancer - ROS/Genitourinary</span>'); 
               break; 
case 'kidney_transplant':  return ('<span class="BlueText">Kidney Transplant - ROS/Genitourinary</span>'); 
               break; 
case 'sexually_transmitted_disease':  return ('<span class="BlueText">Sexually Transmitted Disease - ROS/Genitourinary</span>'); 
               break; 
case 'burning_with_urination':  return ('<span class="BlueText">Burning with Urination - ROS/Genitourinary</span>'); 
               break; 
case 'discharge_from_urethra':  return ('<span class="BlueText">Discharge From Urethra - ROS/Genitourinary</span>'); 
               break; 

//Gastrointestinal (ROS) 
case 'stomach_pains':  return ('<span class="BlueText">Stomach Pains - ROS/Gastrointestinal</span>'); 
               break; 
case 'peptic_ulcer_disease':  return ('<span class="BlueText">Peptic Ulcer Disease - ROS/Gastrointestinal</span>'); 
               break; 
case 'gastritis':  return ('<span class="BlueText">Gastritis - ROS/Gastrointestinal</span>'); 
               break; 
case 'endoscopy':  return ('<span class="BlueText">Endoscopy - ROS/Gastrointestinal</span>'); 
               break; 
case 'polyps':  return ('<span class="BlueText">Polyps - ROS/Gastrointestinal</span>'); 
               break; 
case 'colonoscopy':  return ('<span class="BlueText">Colonoscopy - ROS/Gastrointestinal</span>'); 
               break; 
case 'colon_cancer':  return ('<span class="BlueText">Colon Cancer - ROS/Gastrointestinal</span>'); 
               break; 
case 'colon_cancer_surgery':  return ('<span class="BlueText">Colon Cancer Surgery - ROS/Gastrointestinal</span>'); 
               break; 
case 'ulcerative_colitis':  return ('<span class="BlueText">Ulcerative Colitis - ROS/Gastrointestinal</span>'); 
               break; 
case 'crohns_disease':  return ('<span class="BlueText">Crohn\'s Disease - ROS/Gastrointestinal</span>'); 
               break; 
case 'appendectomy':  return ('<span class="BlueText">Appendectomy - ROS/Gastrointestinal</span>'); 
               break; 
case 'divirticulitis':  return ('<span class="BlueText">Diverticulitis - ROS/Gastrointestinal</span>'); 
               break; 
case 'divirticulitis_surgery':  return ('<span class="BlueText">Diverticulitis Surgery - ROS/Gastrointestinal</span>'); 
               break; 
case 'gall_stones':  return ('<span class="BlueText">Gall Stones - ROS/Gastrointestinal</span>'); 
               break; 
case 'cholecystectomy':  return ('<span class="BlueText">Cholecystectomy - ROS/Gastrointestinal</span>'); 
               break; 
case 'hepatitis':  return ('<span class="BlueText">Hepatitis - ROS/Gastrointestinal</span>'); 
               break; 
case 'cirrhosis_of_the_liver':  return ('<span class="BlueText">Cirrhosis of the Liver - ROS/Gastrointestinal</span>'); 
               break; 
case 'splenectomy':  return ('<span class="BlueText">Splenectomy - ROS/Gastrointestinal</span>'); 
               break; 

//Musculoskeletal (ROS) 
case 'osetoarthritis':  return ('<span class="BlueText">Osetoarthritis - ROS/Musculoskeletal</span>'); 
               break; 
case 'rheumotoid_arthritis':  return ('<span class="BlueText">Rheumotoid Arthritis - ROS/Musculoskeletal</span>'); 
               break; 
case 'lupus':  return ('<span class="BlueText">Lupus - ROS/Musculoskeletal</span>'); 
               break; 
case 'ankylosing_sondlilitis':  return ('<span class="BlueText">Ankylosing Spondlilitis - ROS/Musculoskeletal</span>'); 
               break; 
case 'swollen_joints':  return ('<span class="BlueText">Swollen Joints - ROS/Musculoskeletal</span>'); 
               break; 
case 'stiff_joints':  return ('<span class="BlueText">Stiff Joints - ROS/Musculoskeletal</span>'); 
               break; 
case 'broken_bones':  return ('<span class="BlueText">Broken Bones - ROS/Musculoskeletal</span>'); 
               break; 
case 'neck_problems':  return ('<span class="BlueText">Neck Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'back_problems':  return ('<span class="BlueText">Back Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'back_surgery':  return ('<span class="BlueText">Back Surgery - ROS/Musculoskeletal</span>'); 
               break; 
case 'scoliosis':  return ('<span class="BlueText">Scoliosis - ROS/Musculoskeletal</span>'); 
               break; 
case 'herniated_disc':  return ('<span class="BlueText">Herniated Disc - ROS/Musculoskeletal</span>'); 
               break; 
case 'shoulder_problems':  return ('<span class="BlueText">Shoulder Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'elbow_problems':  return ('<span class="BlueText">Elbow Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'wrist_problems':  return ('<span class="BlueText">Wrist Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'hand_problems':  return ('<span class="BlueText">Hand Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'hip_problems':  return ('<span class="BlueText">Hip Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'knee_problems':  return ('<span class="BlueText">Knee Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'ankle_problems':  return ('<span class="BlueText">Ankle Problems - ROS/Musculoskeletal</span>'); 
               break; 
case 'foot_problems':  return ('<span class="BlueText">Foot Problems - ROS/Musculoskeletal</span>'); 
               break; 



/*----------------------------------------------------------------------------
                     Review of Systems Checks (ROSC)
-----------------------------------------------------------------------------*/ 
//"Constitutional" (ROSC)

			case "weight_change":
return ("Weight Change - ROSC/Constitutional");
break; 

			case "weakness":
return ("Weakness - ROSC/Constitutional");
break; 

			case "fatigue": 
return ("Fatigue - ROSC/Constitutional");
break; 

			case "anorexia":
return ("Anorexia - ROSC/Constitutional");
break; 

			case "fever":
return ("Fever - ROSC/Constitutional");
break; 

			case "chills":
return ("Chills - ROSC/Constitutional");
break; 

			case "night_sweats":
return ("Night Sweats - ROSC/Constitutional");
break; 

			case "insomnia":
return ("Insomnia - ROSC/Constitutional");
break; 

			case "irritability":
return ("Irritability - ROSC/Constitutional");
break; 

			case "heat_or_cold":
return ("Heat or Cold - ROSC/Constitutional");
break; 

			case "intolerance":
return ("Intolerance - ROSC/Constitutional");
break; 
	
		

//"Eyes" (ROSC)

			case "change_in_vision":
return ("Change in Vision - ROSC/Eyes");
break; 

			case "glaucoma_history":
return ("Family History of Glaucoma - ROSC/Eyes");
break; 

			case "eye_pain":
return ("Eye Pain - ROSC/Eyes");
break; 

			case "irritation":
return ("Irritation - ROSC/Eyes");
break; 

			case "redness":
return ("Redness - ROSC/Eyes");
break; 

			case "excessive_tearing":
return ("Excessive Tearing - ROSC/Eyes");
break; 

			case "double_vision":
return ("Double Vision - ROSC/Eyes");
break; 

			case "blind_spots":
return ("Blind Spots - ROSC/Eyes");
break; 

			case "photophobia":
return ("Photophobia - ROSC/Eyes");
break; 

	
		
//"Ears", "Nose", "Mouth", "Throat"  (ROSC)

			case "hearing_loss":
return ("Hearing Loss - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "discharge":
return ("Discharge - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "pain":
return ("Pain - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "vertigo":
return ("Vertigo - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "tinnitus":
return ("Tinnitus - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "frequent_colds":
return ("Frequent Colds - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "sore_throat":
return ("Sore Throat - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "sinus_problems":
return ("Sinus Problems - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "post_nasal_drip":
return ("Post Nasal Drip - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "nosebleed":
return ("Nosebleed - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "snoring":
return ("Snoring - ROSC/Ears,Nose,Mouth,Throat");
break; 

			case "apnea":
return ("Apnea - ROSC/Ears,Nose,Mouth,Throat");
break; 
	
		
//"Breast" (ROSC)

			case "breast_mass":
return ("Breast Mass - ROSC/Breast");
break; 

			case "breast_discharge": 
return ("Discharge - ROSC/Breast");
break; 

			case "biopsy":
return ("Biopsy - ROSC/Breast");
break; 

			case "abnormal_mammogram":
return ("Abnormal Mammogram - ROSC/Breast");
break; 


//"Respiratory"

			case "cough":
return ("Cough - ROSC/Respiratory");
break; 

			case "sputum":
return ("Sputum - ROSC/Respiratory");
break; 

			case "shortness_of_breath":
return ("Shortness of Breath - ROSC/Respiratory");
break; 

			case "wheezing":
return ("Wheezing - ROSC/Respiratory");
break; 

			case "hemoptsyis":
return ("Hemoptysis - ROSC/Respiratory");
break; 

			case "asthma":
return ("Asthma - ROSC/Respiratory");
break; 

			case "copd":
return ("COPD - ROSC/Respiratory");
break; 


//"Cardiovascular" (ROSC)

			case "chest_pain":
return ("Chest Pain - ROSC/Cardiovascular");
break; 

			case "palpitation":
return ("Palpitation - ROSC/Cardiovascular");
break; 

			case "syncope":
return ("Syncope - ROSC/Cardiovascular");
break; 

			case "pnd":
return ("PND - ROSC/Cardiovascular");
break; 

			case "doe":
return ("DOE - ROSC/Cardiovascular");
break; 

			case "orthopnea":
return ("Orthopnea - ROSC/Cardiovascular");
break; 

			case "peripheal":
return ("Peripheral - ROSC/Cardiovascular");
break; 

			case "edema":
return ("Edema - ROSC/Cardiovascular");
break; 

			case "legpain_cramping":
return ("Leg Pain/Cramping - ROSC/Cardiovascular");
break; 

			case "history_murmur":
return ("History of Heart Murmur - ROSC/Cardiovascular");
break; 

			case "arrythmia":
return ("Arrythmia - ROSC/Cardiovascular");
break; 

			case "heart_problem":
return ("Heart Problem - ROSC/Cardiovascular");
break; 
	

//"Gastrointestinal" (ROSC)

			case "dysphagia":
return ("Dysphagia - ROSC/Gastrointestinal");
break; 

			case "heartburn":
return ("Heartburn - ROSC/Gastrointestinal");
break; 

			case "bloating":
return ("Bloating - ROSC/Gastrointestinal");
break; 

			case "belching":
return ("Belching - ROSC/Gastrointestinal");
break; 

			case "flatulence":
return ("Flatulence - ROSC/Gastrointestinal");
break; 

			case "nausea":
return ("Nausea - ROSC/Gastrointestinal");
break; 

			case "vomiting":
return ("Vomiting - ROSC/Gastrointestinal");
break; 

			case "hematemesis":
return ("Hematemesis - ROSC/Gastrointestinal");
break; 

			case "gastro_pain":
return ("Pain - ROSC/Gastrointestinal");
break; 

			case "food_intolerance":
return ("Food Intolerance - ROSC/Gastrointestinal");
break; 

			case "hepatitis":
return ("H/O Hepatitis - ROSC/Gastrointestinal");
break; 

			case "jaundice":
return ("Jaundice - ROSC/Gastrointestinal");
break; 

			case "hematochezia":
return ("Hematochezia - ROSC/Gastrointestinal");
break; 

			case "changed_bowel":
return ("Changed Bowel - ROSC/Gastrointestinal");
break; 

			case "diarrhea":
return ("Diarrhea - ROSC/Gastrointestinal");
break; 

			case "constipation":
return ("Constipation - ROSC/Gastrointestinal");
break; 


//"Genitourinary 1" (ROSC)

			case "polyuria":
return ("Polyuria - ROSC/Genitourinary1");
break; 

			case "polydypsia":
return ("Polydypsia - ROSC/Genitourinary1");
break; 

			case "dysuria":
return ("Dysuria - ROSC/Genitourinary1");
break; 

			case "hematuria":
return ("Hematuria - ROSC/Genitourinary1");
break; 

			case "frequency":
return ("Frequency - ROSC/Genitourinary1");
break; 

			case "urgency":
return ("Urgency - ROSC/Genitourinary1");
break; 

			case "incontinence":
return ("Incontinence - ROSC/Genitourinary1");
break; 

			case "renal_stones":
return ("Renal Stones - ROSC/Genitourinary1");
break; 

			case "utis":
return ("UTIs - ROSC/Genitourinary1");
break; 


//"Genitourinary 2" (ROSC)
			
			case "hesitancy":
return ("Hesitancy - ROSC/Genitourinary2");
break; 

			case "dribbling":
return ("Dribbling - ROSC/Genitourinary2");
break; 

			case "stream":
return ("Stream - ROSC/Genitourinary2");
break; 

			case "nocturia":
return ("Nocturia - ROSC/Genitourinary2");
break; 

			case "erections":
return ("Erections - ROSC/Genitourinary2");
break; 

			case "ejaculations":
return ("Ejaculations - ROSC/Genitourinary2");
break; 


//"Genitourinary 3" (ROSC)

			case "g":
return ("Female G - ROSC/Genitourinary3");
break; 

			case "p":
return ("Female P - ROSC/Genitourinary3");
break; 

			case "ap":
return ("Female AP - ROSC/Genitourinary3");
break; 

			case "lc":
return ("Female LC - ROSC/Genitourinary3");
break; 

			case "mearche":
return ("Menarche - ROSC/Genitourinary3");
break; 

			case "menopause":
return ("Menopause - ROSC/Genitourinary3");
break; 

			case "lmp":
return ("LMP - ROSC/Genitourinary3");
break; 

			case "f_frequency":
return ("Frequency - ROSC/Genitourinary3");
break; 

			case "f_flow":
return ("Flow - ROSC/Genitourinary3");
break; 

			case "f_symptoms":
return ("Symptoms - ROSC/Genitourinary3");
break; 

			case "abnormal_hair_growth":
return ("Abnormal Hair Growth - ROSC/Genitourinary3");
break; 

			case "f_hirsutism":
return ("F/H Female Hirsutism/Striae - ROSC/Genitourinary3");
break; 


//"Musculoskeletal" (ROSC)

			case "joint_pain":
return ("Chronic Joint Pain - ROSC/Musculoskeletal");
break; 

			case "swelling":
return ("Swelling - ROSC/Musculoskeletal");
break; 

			case "m_redness":
return ("Redness - ROSC/Musculoskeletal");
break; 

			case "m_warm":
return ("Warm - ROSC/Musculoskeletal");
break; 

			case "m_stiffness":
return ("Stiffness - ROSC/Musculoskeletal");
break; 

			case "muscle":
return ("Muscle - ROSC/Musculoskeletal");
break; 

			case "m_aches":
return ("Aches - ROSC/Musculoskeletal");
break; 

			case "fms":
return ("FMS - ROSC/Musculoskeletal");
break; 

			case "arthritis":
return ("Arthritis - ROSC/Musculoskeletal");
break; 


//"Neurologic" (ROSC)

			case "loc":
return ("LOC - ROSC/Neurologic");
break; 

			case "seizures":
return ("Seizures - ROSC/Neurologic");
break; 

			case "stroke":
return ("Stroke - ROSC/Neurologic");
break; 

			case "tia":
return ("TIA - ROSC/Neurologic");
break; 

			case "n_numbness":
return ("Numbness - ROSC/Neurologic");
break; 

			case "n_weakness":
return ("Weakness - ROSC/Neurologic");
break; 

			case "paralysis":
return ("Paralysis - ROSC/Neurologic");
break; 

			case "intellectual_decline":
return ("Intellectual Decline - ROSC/Neurologic");
break; 

			case "memory_problems":
return ("Memory Problems - ROSC/Neurologic");
break; 

			case "dementia":
return ("Dementia - ROSC/Neurologic");
break; 

			case "n_headache":
return ("Headache - ROSC/Neurologic");
break; 


//"Skin" (ROSC)

			case "s_cancer":
return ("Cancer - ROSC/Skin");
break; 

			case "psoriasis":
return ("Psoriasis - ROSC/Skin");
break; 

			case "s_acne":
return ("Acne - ROSC/Skin");
break; 

			case "s_other":
return ("Other - ROSC/Skin");
break; 

			case "s_disease":
return ("Disease - ROSC/Skin");
break; 


//"Psychiatric" (ROSC)
			
			case "p_diagnosis":
return ("Psychiatric Diagnosis - ROSC/Psychiatric");
break; 

			case "p_medication":
return ("Psychiatric Medication - ROSC/Psychiatric");
break; 

			case "depression":
return ("Depression - ROSC/Psychiatric");
break; 

			case "anxiety":
return ("Anxiety - ROSC/Psychiatric");
break; 

			case "social_difficulties":
return ("Social Difficulties - ROSC/Psychiatric");
break; 


//"Endocrine" (ROSC)
			case "thyroid_problems":
return ("Thyroid Problems - ROSC/Endocrine");
break; 

			case "diabetes":
return ("Diabetes - ROSC/Endocrine");
break; 

			case "abnormal_blood":
return ("Abnormal Blood Test - ROSC/Endocrine");
break; 


//"Hematologic" (ROSC)

			case "anemia":
return ("Anemia - ROSC/Hematologic");
break; 

			case "fh_blood_problems":
return ("F/H Blood Problems - ROSC/Hematologic");
break; 

			case "bleeding_problems":
return ("Bleeding Problems - ROSC/Hematologic");
break; 

			case "allergies":
return ("Allergies - ROSC/Hematologic");
break; 

			case "frequent_illness":
return ("Frequent Illness - ROSC/Hematologic");
break; 

			case "hiv":
return ("HIV - ROSC/Hematologic");
break; 
			case "hai_status":
return ("HAI Status - ROSC/Hematologic");
break; 

       default:
                break;
  
              
}}

