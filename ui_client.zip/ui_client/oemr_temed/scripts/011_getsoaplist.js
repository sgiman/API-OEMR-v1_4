/*************************************************************************************************
 *   012_getsoaplist.js
 *
 *   Get Soap List
 *   API is allowed to get list of patient SOAP (Subjective, Objective, Assessment and Plan) details
 *
 *   http://sgiman.com.ua/openemr/api/getsoaplist.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {
      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
        $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   

});


/////////////////////////////////////// 
//          Patient Select
///////////////////////////////////////

function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getsoaplist.php?token=' + key +
  '&patientId=' + g_pid + '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  soaplistData(g_pid, g_txt);
  fetch(g_pid, g_txt);
   
}


/////////////////////////////////////// 
//           Get Soap List
///////////////////////////////////////

function fetch(pid, txt) {
    setTimeout ( function() 
    {
      soaplistData(pid, txt);
      fetch(pid, txt);
    }, timeout);
}


function soaplistData (pid, txt) 
{

    // 2. AJAX - SOAP LIST
    $.ajax ({
  
    url: server + "/openemr/api/getsoaplist.php?token=" + key + "&patientId=" + pid,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("list").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })
      
      // Request API OEMR - XML Parsing
      $(data).find("soap").each ( function() {
      
      var info = 
              
       '<h3 id="title">' + txt + '&nbsp; ID: ' + $(this).find("visit_id").text() + '</h3>' +         
       '<li><b>ID:</b> ' +  $(this).find("id").text() + '</li>' +
       '<li><b>Sate:</b> ' +  $(this).find("date").text() + '</li>' +
       
       '<br><li><b><font size="4" color="red">Subjective:</font></b> ' +  $(this).find("subjective").text() + '</li>' +
       '<br><li><b><font size="4" color="Chocolate">Objective:</font></b> ' +  $(this).find("objective").text() + '</li>' +
       '<br><li><b><font size="4" color="BlueViolet">Assessment:</font></b> ' +  $(this).find("assessment").text() + '</li>' +
       '<br><li><b><font size="4" color="blue">Plan:</font></b> ' +  $(this).find("plan").text() + '</li>' +
       
       '<br><li><b>user:</b> ' +  $(this).find("user").text() + '</li>' +
       '<li><b>firstname:</b> ' +  $(this).find("firstname").text() + '</li>' + 
       '<li><b>lastname:</b> ' +  $(this).find("lastname").text() + '</li>' + '<hr><br>';
         
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })

}
