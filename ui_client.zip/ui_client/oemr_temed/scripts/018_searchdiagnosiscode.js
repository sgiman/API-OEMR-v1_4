/*************************************************************************************************
 *   018_searchdiagnosiscode.js
 *
 *   Search Diagnosis Code (ICD9,ICD10) - DC
 *   API is allowed to search diagnosis code 
 *
 *   http://sgiman.com.ua/openemr/api/searchdiagnosiscode.php?token=df19b7027c8cab07db1e9eef0566e1c9&code_type=icd9&search_term=Joint
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9
 *
 *   Parameters:
 *   ------------  
 *   token
 *   search_term     
 *   code_type=icd9, icd10
 *   ---------------------------------------------------------------------    
 *                                    SAMPLES:
 *   ---------------------------------------------------------------------    
 *   Problem:
 *   -------
 *   asthma, Cervical, Cancer, Cyanosis, diabetes, 
 *   HTN, hyperlipidemia, Jaw Pain, Pain, Jaw, Joint Deformity, 
 *   Joint, Deformity, Redness, Mouth, Sores, Multiple Sclerosis, 
 *   Bladder, Postnasal Drip, Sore, Tongue,  Wheezing
 *
 *   Allergy:
 *   ---------
 *   Cephalosporins, Intravenous, iodine, Local, anesthetics, Non-steroidal 
 *   anti-inflammatori, penicillin, Sulfonamides, Tetracycline
 *      
 *   Surgery:
 *   ---------
 *   cholecystectomy
 *
 *   Dental:  
 *   ---------
 *   breath, gum, disease, mouth, oral, cancer, toothaches, Dental, tooth, erosion, sensitivity
 *     
 *-----------------------------------------------------------------------------------------------
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 ************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'API is allowed to search diagnosis code (ICD9,ICD10)'; 

$(document).ready( function () 
{
  
  // TITLE TEST
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

});


/////////////////////////////////////// 
//            Search Codes
///////////////////////////////////////

function SearchCode()
{

  //var Code_Name = document.getElementById("CodeName").value;    
  var CodeType  = $("#CodeType option:selected").val();
  var CodeName  = $("#CodeName").val();
     
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + CodeName + ' : ' + CodeType.toUpperCase() + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/searchdiagnosiscode.php?token=' + key + 
  '&code_type=' + CodeType  + '&search_term=' + CodeName + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');

  DiagnosisCodeData(CodeType, CodeName);
  fetch(CodeType, CodeName);
   
}


////////////////////////////////////////////// 
// AJAX - Search Diagnosis Code (ICD9,ICD10)
////////////////////////////////////////////// 

function fetch(CodeType, CodeName) {
    setTimeout ( function() 
    {
      DiagnosisCodeData(CodeType, CodeName);
      fetch(CodeType, CodeName);
    }, timeout);
}


function DiagnosisCodeData (CodeType, CodeName) 
{
    
    var i = 0; 
        
    $.ajax ({
  
    url: server + "/openemr/api/searchdiagnosiscode.php?token=" + key +  
    '&code_type=' + CodeType + '&search_term=' + CodeName,

    dataType: "xml",
    type: "GET",
    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("DiagnosisCodes").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);  
      })
      

      // Request API OEMR - XML Parsing
      $(data).find("DiagnosisCode").each ( function() {
      
      var info = 
         
      '<li><b>CODE: ' +  '<font size="4" color="Crimson">' + $(this).find("code_type_name").text() + ':' +
        $(this).find("code").text()+ '</font></b></li>' +
      
      '<li><b>Code Text:</b> ' +  $(this).find("code_text").text() + '</li>' +     
      '<li><b>Code Text Short:</b> ' +  $(this).find("code_text_short").text() + '</li>' + '<hr><br>';           
       
      i = i + 1; 
      
      $("#OEMR").append(info);    

      })

     $('#Name').html('<h1> &nbsp; .... &nbsp;' + CodeName + ' : ' 
     + CodeType.toUpperCase() + ' / ' + '<font color="Crimson">' + "Search Results (" + i + " items)"  +  '</font></h1>');
     
     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
                   
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }  
      
  })


}
