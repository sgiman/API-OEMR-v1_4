/*************************************************************************************************
 *   footer.js
 *   
 *   FOOTER PAGES
 *
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/

$(document).ready ( function () {

// FOOTER
var footer_page = 

'<font color="#585858">&copy; Copyright @ 2016 tEMed Holdings, LLC. All rights reserved.</font>' +
'<div style="margin-left: -5px; margin-top: 10px;">' +
'<a href="http://spine.temed.com/" target="_blank"><span><img id="footer-logo" src="images/temed.png" alt="temed"></span></a>' +
'<a href="http://sgiman.com.ua/openemr" target="_blank"><span><img id="footer-logo" src="images/oemr.png" alt="OpenEMR"></span></a>' +
'</div>' +

'<div style="float: right; margin-top: -32px; font-size: 15px;">' +
'<font color="#585858">Demographics &nbsp;&#9679;&nbsp; Clinical &nbsp;&#9679;&nbsp; Insurances &nbsp;&#9679;&nbsp; Rx &nbsp;&#9679; ICD9 &nbsp;&#9679;&nbsp; ICD10 &nbsp;&#9679;'+ 
'<br>Billing &nbsp;&#9679;&nbsp; Reports &nbsp;&#9679;&nbsp; Appointments &nbsp;&#9679; RxNorm &nbsp;&#9679; SNOMED &nbsp;&#9679; EDI  &nbsp;&#9679;' +
'<br>CCR &nbsp;&#9679;&nbsp; CCD &nbsp;&#9679;&nbsp; HL7 &nbsp;&#9679;&nbsp; HIPAA &nbsp;&#9679;&nbsp; ONC</font>' +
'</div>' +

'<div align="center" style="margin-top: -65px;">' +
'<div style="width: 120px";>' +
'<a href="http://www.temed.com/" target="_blank">' +
'<span><img id="temed-logo" src="images/TEMED-SQ.jpg" alt="temed" ></span></a></div>' +
'</div><br><br><br>'

$( "footer" ).append(footer_page);


});



