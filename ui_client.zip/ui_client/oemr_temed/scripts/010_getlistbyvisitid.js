/*************************************************************************************************
 *   009_getlistbyvisitid.js
 *
 *   Get List by Visitid
 *   API returns all list items related to any particular visit id
 *
 *   http://sgiman.com.ua/openemr/api/getlistbyvisitid.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
      {

        // Remove elements 
        if ($(this) != '') $("#PID").children().remove();   

        // PATIENTS (Select:Options)
        $("#PID").append('<option selected value="0">NONE</option>');
        $(data).find("Patient").each( function() 
        {
          var pat =
          '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
          $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
          $("#PID").append(pat);
          //alert(pat);      
   
        })

      }

    })   
  

});


/////////////////////////////////////// 
//          Patient Select
///////////////////////////////////////

function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getlistbyvisitid.php?token=' + key + 
  '&patientId=' + g_pid + '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  listbyvisitData(g_pid,g_txt);
  fetch(g_pid, g_txt);
   
}


/////////////////////////////////////// 
//         Get List by Visitid
///////////////////////////////////////

function fetch(pid,txt) {
    setTimeout ( function() 
    {
      listbyvisitData(pid,txt);
      fetch(pid,txt);
    }, timeout);
}


function listbyvisitData (pid,txt) 
{
     
    // 2. AJAX - List by Visitid
    $.ajax ({
  
    url: server + "/openemr/api/getlistbyvisitid.php?token=" + key + "&patientId=" + pid,
    
    dataType: "xml",
    type: "GET",
    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("Listitems").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("listitem").each ( function() {
      
      var info = 
      '<h3 id="title">' + txt + '&nbsp; &nbsp; ID: ' +  $(this).find("id").text() + '</h3>' +
      '<li><b>Patient ID:</b> ' +  $(this).find("pid").text() + '</li>' +
      '<li><b>Type:</b> ' +  $(this).find("type").text() + '</li>' +
      '<li><b>Title: ' +  '<font color="Crimson" size=4>' + $(this).find("title").text() + '</font></b></li>' +
      '<li><b>Begin Date:</b> ' +  $(this).find("begdate").text() + '</li>' +
      '<li><b>End Date:</b> ' +  $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date:</b> ' +  $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence:</b> ' +  $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification:</b> ' +  $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by:</b> ' +  $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info:</b> ' +  $(this).find("extrainfo").text() + '</li>' +
      '<li><b>Diagnosis:</b> ' +  $(this).find("diagnosis").text() + '</li>' +
      '<li><b>Activity:</b> ' +  $(this).find("activity").text() + '</li>' +
      '<li><b>Comments:</b> ' +  $(this).find("comments").text() + '</li>' +
      '<li><b>User:</b> ' +  $(this).find("user").text() + '</li>' +
      '<li><b>Groupname:</b> ' +  $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome:</b> ' +  $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination:</b> ' +  $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury id:</b> ' +  $(this).find("reinjury_id").text() + '</li>' +
      '<li><b>Injury part:</b> ' +  $(this).find("injury_part").text() + '</li>' +
      '<li><b>Injury type:</b> ' +  $(this).find("injury_type").text() + '</li>' +
      '<li><b>Injury grade:</b> ' +  $(this).find("injury_grade").text() + '</li>' +
      '<li><b>Reaction:</b> ' +  $(this).find("reaction").text() + '</li>' +
      '<li><b>External Allergy ID:</b> ' +  $(this).find("external_allergyid").text() + '</li>' +   
      '<li><b>eRx Source:</b> ' +  $(this).find("erx_source").text() + '</li>' +  
      '<li><b>eRx Uploaded:</b> ' +  $(this).find("erx_uploaded").text() + '</li>' +
      '<li><b>Modify Date:</b> ' +  $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title:</b> ' +  $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';
      
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}
