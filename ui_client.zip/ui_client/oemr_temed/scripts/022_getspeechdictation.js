/*************************************************************************************************
 *   022_getspeechdictation.js
 *
 *   Get Speech Dictation
 *   API is allowed to get patient Speech Dictation for a visit/encounter
 *
 *   http://sgiman.com.ua/openemr/api/getspeechdictation.php?token=df19b7027c8cab07db1e9eef0566e1c9&visit_id=330
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   visit_id = 330 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.3                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    ////////////////////////////////
    //  1. AJAX - PATIENTS LIST
    ////////////////////////////////
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + 
        $(this).find("firstname").text() + ' ' +  $(this).find("lastname").text() + 
        ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   
});


/*-------------------------------------------------------------------------------------
                 2. AJAX - Get Patient Visits (options select)
---------------------------------------------------------------------------------------*/
/***************************************************************************************
 *   Get Visits
 *   API returns all list items related to any particular visit id
 *
 *   "http://sgiman.com.ua/openemr/api/
 *    getvisits.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10" 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *
******************************************************************************************/
// --- Patient Select
function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getvisits.php?token=' + key + '&patientId=' + g_pid + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  visitsData(g_pid, g_txt);
  fetch_vis(g_pid, g_txt);
   
}

/////////////////////////////////////// 
//        2. AJAX - Get Visits
///////////////////////////////////////

function fetch_vis (pid, txt) {
    setTimeout ( function() 
    {
      visitsData(pid, txt);
      fetch_vis (pid, txt);
    }, timeout);
}


function visitsData (pid,txt) 
{
 
    $.ajax ({
  
      url: server + "/openemr/api/getvisits.php?token=" + key + "&patientId=" + pid,
      dataType: "xml",
      type: "GET",
      success: function (data) 
        {

          // Remove elements 
          if ($(this) != '') $("#OEMR").children().remove();   
          if ($(this) != '') $("#PVIS").children().remove();   
          $("#LOAD").children().remove();
          $("#to-top").children().remove();

          // Status Reason
          $(data).find("PatientVisit").text ( function() 
          {
            var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' +  
            $(this).find("status").text() + '</h2>'; 
            $('#Status').html(status);      
          })

          // Request API OEMR - XML Parsing
          $(data).find("Visit").each ( function() {
       
          var info = 
          '<option value="' + $(this).find("encounter").text() + '">' + 
          $(this).find("encounter").text() + ' / ' + txt + '</option>'; 
           
          $("#PVIS").append(info);
            
          })

       },

  })

}


/////////////////////////////////////// 
//  3. AJAX - Get Speech Dictation
///////////////////////////////////////

// INPUT ENCOUNTER OPTIONS 
function Result(){

    var vid_val  = $("#PVIS option:selected" ).val();
    var vid_txt  = $("#PVIS option:selected" ).text();

    $('#Name').html('<h1><font color="Crimosn"> &nbsp; .... &nbsp;Encounter: </font>' + vid_txt + '</h1>');
    
    // XML REQUEST
    $('#XML').html('<a href="' + server + '/openemr/api/getspeechdictation.php?token=' + key + '&visit_id=' + vid_val + 
    '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
    
    sdicData (vid_val, vid_txt);
    fetch_dic (vid_val, vid_txt);
}


function fetch_dic (vid, txt) {
    setTimeout ( function() 
    {
      sdicData (vid, txt);
      fetch_dic (vid, txt);
    }, timeout );
}


function sdicData (vid, txt) 
{
    $.ajax ({
  
    url: server + "/openemr/api/getspeechdictation.php?token=" + key + "&visit_id=" + vid,
    
    dataType: "xml",
    type: "GET",
    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("speechdictations").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing     
      $(data).find("speechdictation").each ( function() {
      
      var info = 
      
      '<h3 id="title">Encounter &nbsp;' + txt + '&nbsp; ID: ' + $(this).find("id").text()  +'</h3>' +      
      '<li><b>Date:</b> ' + $(this).find("date").text() + '</li>' +
      '<br><li><b><font size="4" color="blue">Dictation:</font></b> ' + $(this).find("dictation").text() + '</li>' +
      '<br><li><b><font size="4" color="Chocolate">Additional Notes:</font></b> ' + $(this).find("additional_notes").text() + '</li>' +

      '<br><li><b>User:</b> ' + $(this).find("user").text() + '</li>' +
      '<li><b>Provider:</b> ' + $(this).find("firstname").text() + ' ' + 
      $(this).find("lastname").text() + '</li>' + '<hr><br>';
         
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}
