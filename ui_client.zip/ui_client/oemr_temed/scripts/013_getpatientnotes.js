/*************************************************************************************************
 *   014_getpatientnotes.js
 *
 *   Get Patient Note
 *   API to get patient notes
 *
 *   http://sgiman.com.ua/openemr/api/getpatientnotes.php?token=df19b7027c8cab07db1e9eef0566e1c9&listId=8&patientId=10
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   listId = 8
 *   patientId = 10 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + 
        $(this).find("firstname").text() + ' ' +  $(this).find("lastname").text() + 
        ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   

});


/////////////////////////////////////// 
//          Patient Select
///////////////////////////////////////

function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getpatientnotes.php?token=' + key +
  '&listId=8&patientId='+ g_pid + '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  patientnotesData(g_pid, g_txt);
  fetch(g_pid, g_txt);
   
}


/////////////////////////////////////// 
//          Get Patient Note
///////////////////////////////////////

function fetch(pid, txt) {
    setTimeout ( function() 
    {
      patientnotesData(pid, txt);
      fetch(pid, txt);
    }, timeout);
}


function patientnotesData (pid, txt) 
{
    // 1. AJAX - PATIENT NOTES 

    $.ajax ({
  
    url: server + "/openemr/api/getpatientnotes.php?token=" + key + "&listId=8&patientId=" + pid,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("PatientNotes").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })
      
      // Request API OEMR - XML Parsing
      $(data).find("patientnote").each ( function() {
      
      var info =

       '<h3 id="title">' + txt + '&nbsp; ID: ' +  $(this).find("id").text() + '</h3>' + 
       '<li><b>Date:</b> ' +  $(this).find("date").text() + '</li>' +
       '<br><li><b><font size="4" color="red">Note:</font></b> ' +  $(this).find("body").text() + '</li>' +
       '<br><li><b>User:</b> ' +  $(this).find("user").text() + '</li>' +
       '<li><b>Activity:</b> ' +  $(this).find("activity").text() + '</li>' +
       '<li><b>Title:</b> ' +  $(this).find("title").text() + '</li>' +
       '<li><b>Assigned to:</b> ' +  $(this).find("assignedto").text() + '</li>' +
       '<li><b>Message Status:</b> ' +  $(this).find("messagestatus").text() + '</li>' + '<hr><br>';
       
         
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })

}
