/*************************************************************************************************
 *   006_report_appointments.js
 *  
 *   Report Appointments
 *   API is allowed to get patient appointments report
 *
 *   http://sgiman.com.ua/openemr/api/report_appointments.php?token=df19b7027c8cab07db1e9eef0566e1c9&from_date=2016-08-01&to_date=2016-08-31
 *
 *   For testing - login is disable!
 *   token=df19b7027c8cab07db1e9eef0566e1c9 
 *
 *   from_date=2016-08-01
 *   to_date=2016-08-31
 *   facility=6
 *   provider=7
 *   show_available_times=10:00
 *   (time  - only XML)
 *   -------------------------------------------------------------------------------------------------
 *   APOINTMENT CATEGORY (pc_catid): 
 *     1   - No Show (Reserved to define when an event did not occur as specified)
 *     2   - In Office (Reserved todefine when a provider may haveavailable appointments after)
 *     3   - Out Of Office (Reserved to define when a provider may not have available appointments after)
 *     4   - Vacation (Reserved for use to define Scheduled Vacation Time)
 *     5   - Office Visit (Normal office visit)
 *     8   - Lunch 
 *     9   - Established Patient
 *     10  - New Patient
 *     11  - Video Online Consultation (telemedicine, video chat)
 *     12  - Online Consultation (sound, chat)
 *   -------------------------------------------------------------------------------------------------
 *   APOITMENT STATUSES (pc_apptstatus):
 *    - None
 *    * Reminder done
 *    + Chart pulled
 *    x Canceled
 *    ? No show
 *    @ Arrived
 *    ~ Arrived late
 *    ! Left w/o visit
 *    # Ins/fin issue
 *    < In exam room
 *    > Checked out
 *    $ Coding done
 *    % Canceled < 24h
 *   -------------------------------------------------------------------------------------------------
 * 
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST - <font size="6" color="red">tEMed</font>'
var time=""

$(document).ready( function () 
{
    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');   

    /////////////////////////////
    // 1. AJAX - PROVIDERS LIST
    /////////////////////////////
    $.ajax ({
  
    url: server + "/openemr/api/getproviders.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PROVIDER").children().remove();   

      // PROVIDERS (Select:Options)
      $("#PROVIDER").append('<option selected value=""> ALL </option>');
      
      $(data).find("Provider").each( function() 
      {
        var provider =
        '<option value="' + $(this).find("id").text() + '">' + $(this).find("fname").text() + ' ' +  
        $(this).find("lname").text() + ' (' +  $(this).find("id").text() + ')</option>'; 
    
        $("#PROVIDER").append(provider);
   
      })

    }

    })   

    ////////////////////////////////////////
    // 2. AJAX - FACILITIES LIST (CLINICS)
    ////////////////////////////////////////
    $.ajax ({
  
    url: server + "/openemr/api/getfacility.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#FACILITY").children().remove();   

      // FACILITY (Select:Options)
      $("#FACILITY").append('<option selected value=""> ALL </option>');
      
      $(data).find("facility").each( function() 
      {
        var facility =
        '<option value="' + $(this).find("id").text() + '">' + $(this).find("name").text() + 
        ' (' +  $(this).find("id").text() + ')</option>'; 
    
        $("#FACILITY").append(facility);
   
      })

    }

    })   

});

////////////////////////////
//    INPUT PARAMETERS 
///////////////////////////
function Result(){

    var time  = document.appointment.time.value;
    var provider_t  = $("#PROVIDER option:selected" ).text();
    var facility_t  = $("#FACILITY option:selected" ).text();
    
    var provider  = $("#PROVIDER option:selected" ).val();
    var facility  = $("#FACILITY option:selected" ).val();
    
    var date_from = byId("date_from").value;
    var date_to   = byId("date_to").value;
    
    // TITLE TEST
    t = date_from + ' / ' + date_to + '  - ' + provider_t + ', ' + facility_t;
    t = t + ' - <font size="6" color="red">teMEd</font>'; 
    
    if (time !='')
      $('#Name').html('<h2> &nbsp; .... &nbsp;' + t + ', ' + time + '</h2>');
    else  
      $('#Name').html('<h2> &nbsp; .... &nbsp;' + t + '</h2>');  

    // XML REQUEST
    $('#XML').html('<a href="' + server + '/openemr/api/report_appointments.php?token=' + key + 
    '&from_date=' + date_from + 
    '&to_date='   + date_to + 
    '&provider='  + provider +  
    '&facility='  + facility + 
    '"><img  style="margin: -10px 0px" align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');

    appointmentsData (date_from, date_to, provider, provider_t, facility, facility_t, time);
    fetch(date_from, date_to, provider, provider_t, facility, facility_t, time);
}


/////////////////////////////////////// 
//        Report Appointments
///////////////////////////////////////

function fetch(date_from, date_to, provider, provider_t, facility, facility_t, time) {
    setTimeout ( function() 
    {
      appointmentsData(date_from, date_to, provider, provider_t, facility, facility_t, time);
      fetch(date_from, date_to, provider, provider_t, facility, facility_t, time);
    }, timeout);
    
}

/*----------------------------
      Appointments Data
----------------------------*/
function appointmentsData (date_from, date_to, provider, provider_t, facility, facility_t, time) 
{  
    
    var status;
     
    if (provider == "ALL") provider = 0;   
    if (facility == "ALL") facility = 0;   
           
    // 3. AJAX - APPOINTMENTS    
    $.ajax ({
  
    url: server + "/openemr/api/report_appointments.php?token=" + key + 
    '&from_date=' + date_from + '&to_date=' + date_to + '&provider=' + provider + '&facility=' + facility,
    
    dataType: "xml",
    type: "GET",
    
    success: 
  
    function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();
      $("#NO_RESULT").children().remove();
      //$("#Scheduler").children().remove();
      
      // Status Reason
      $(data).find("list").each ( function() 
      {
          var  status_reason = '<h2><span class="BlueText">STATUS REASON: <\span>' + $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status_reason);          
      })
      
      // Request API OEMR - XML Parsing

      var office = 0;
      var online = 0;
      var visits = 0;

      $(data).find("appointment").each ( function() {

      var stm = $(this).find("pc_startTime").text();
           

      // if time is enabled
      if (time !='' && stm == (time + ':00'))
      {
      
      if ($(this).find("pc_eventDate").text() != "")  visits = visits + 1;
      if ($(this).find("pc_catid").text() == "5")  office = office + 1;
      if ($(this).find("pc_catid").text() == "11")  online = online + 1;
      if ($(this).find("pc_catid").text() == "12")  online = online + 1;

        var info = 

        '<h3 id="title">Patient: ' + '<font size=5>' + 
        $(this).find("lname").text() +  ' (' +  $(this).find("pid").text() + ')' +  '</font></h3>' + 
      
        '<li><b>Event Date: ' + '<span class="TextRedBg">' + $(this).find("pc_eventDate").text() + '</span></b></li>' +
        '<li><b>End Date: </b>' +  $(this).find("pc_endDate").text() + '</font></li>' +
        '<li><b>Start Time: ' +  '<span t' + '<span class="TextBlueBg">' + $(this).find("pc_startTime").text() + '</li></b>' +
        '<li><b>End Time: </b>' +  $(this).find("pc_endTime").text() + '</li>' +
        '<li><b>Duration:</b> ' +  $(this).find("pc_duration").text() + '</li>' +
        '<li><b>Title:</b> ' +  $(this).find("pc_title").text() + '</li>' +
        '<li><b>Appointment Status: ' +  '<font color=Crimson>' + $(this).find("pc_apptstatus").text() + '</font></b></li>' +
        '<li><b>Phone Home:</b> ' +  $(this).find("phone_home").text() + '</li>' +
        '<li><b>Phone Cell:</b> ' +  $(this).find("phone_cell").text() + '</li>' +
      
        '<li><b><font size=5 color="#427db7">Provider: ' +  $(this).find("ufname").text() + ' ' +  
        $(this).find("ulname").text() + ' (' + $(this).find("uprovider_id").text() + ')  - ' + facility_t + '</font></b></li>' +
      
        '<li><font color="Crimson"><b>Type Visit: ' +  $(this).find("pc_catname").text() + '</b></font></li>' +   
        '<li><b>Comment:</b> ' +  $(this).find("pc_hometext").text() + '</b></li>' + '<hr><br>';  

      }
           
     // if for all times    
     if (time == '')
      {

      if ($(this).find("pc_eventDate").text() != "")  visits = visits + 1;
      if ($(this).find("pc_catid").text() == "5")  office = office + 1;
      if ($(this).find("pc_catid").text() == "11")  online = online + 1;
      if ($(this).find("pc_catid").text() == "12")  online = online + 1;

        var info = 

        '<h3 id="title">Patient: ' + '<font size=5>' + 
        $(this).find("lname").text() +  ' (' +  $(this).find("pid").text()  + ')</font></h3>' + 
      
        '<li><b>Event Date: ' + '<span class="TextRedBg">' + 
        $(this).find("pc_eventDate").text() + '</span></b></li>' +
      
        '<li><b>End Date: </b>' +  $(this).find("pc_endDate").text() + '</font></li>' +
      
        '<li><b>Start Time: ' +  '<span t' + '<span class="TextBlueBg">' + 
        $(this).find("pc_startTime").text() + '</li></b>' +
      
        '<li><b>End Time: </b>' +  $(this).find("pc_endTime").text() + '</li>' +
        '<li><b>Duration:</b> ' +  $(this).find("pc_duration").text() + '</li>' +
        '<li><b>Title:</b> ' +  $(this).find("pc_title").text() + '</font></li>' +
      
        '<li><b>Appointment Status: ' +  '<font color=Crimson>' + 
        $(this).find("pc_apptstatus").text() + '</font></b></li>' +
      
        '<li><b>Phone Home:</b> ' +  $(this).find("phone_home").text() + '</li>' +
        '<li><b>Phone Cell:</b> ' +  $(this).find("phone_cell").text() + '</li>' +
      
        '<li><b><font size=5 color="#427db7">Provider: ' +  
        $(this).find("ufname").text() + ' ' +  $(this).find("ulname").text() + ' (' + 
        $(this).find("uprovider_id").text() + ')  - ' + 
        facility_t + '</font></b></li>' +
      
        '<li><font color="Crimson"><b>Type Visit: ' +  $(this).find("pc_catname").text() + '</b></font></li>' +   
        '<li><b>Comment:</b> ' +  $(this).find("pc_hometext").text() + '</li>' + '<hr><br>';  
      
      }
      
      $("#OEMR").append(info);
           
      })

     // ADD Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     // ADD Scheduler 
     //$("#Scheduler").append ('<a href="tools/scheduler/calendar/05_calendar/01_select.html"><figure><img src="images/Schedular_API_EMR.png" alt="Shceduler"></figure></a>');
  
     // ADD NOT_FOUND
     $(data).find("list").each ( function() 
     {
        status = $(this).find("status").text();    
        //alert (status);  
        if (status != '0') {$("#NO_RESULT").html('<div style="margin-left:40px"><img src="images/no-result.png" alt="Not Result"></div>')};
     })

      // TITLE TEST
      var t = date_from + ' / ' + date_to + ' - ' + provider_t + ', ' + facility_t + 
      '<font color="Crumson">/ ' +  visits + ' visits, ' + ' ' + 
      office + ' office, ' + ' ' + online + " online</font>" ;
      
      if (time !='') 
        $('#Name').html('<h2> &nbsp; .... &nbsp;' + t + ', ' + time + '</h2>');
      else  
        $('#Name').html('<h2> &nbsp; .... &nbsp;' + t + '</h2>');  
      
        
      },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })

}

//------------------------------------------
// HELP:
// INFO: xml atribute
// $xml.find('item[name="001"]'));
// RANDOM:
//  alert (Math.random() * 100 >> 0);
//  alert (Math.random() * 5 >> 0);
//------------------------------------------
