/*************************************************************************************************
 *   005_getpatientdocuments.js
 *
 *   Get Patient Documents
 *   API fetch and return all patient documents of any type
 *
 *   http://sgiman.com.ua/openemr/api/getpatientdocuments.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=3&categoryId=5
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9
 *   
 *      &patientId=
 *      &categoryId=
 *
 *   -----------------------------------
 *      Category Documents ID:  
 *        2  - Lab Report
 *        3  - Medical Record
 *        5  - Patient ID card
 *        10 - Patient Photograph
 *        11 - CCR
 *        12 - CCD
 *   -----------------------------------
 *
 *   MySQL table: documents 
 *   listId, docDate, categoryId, data, docType, mimeType
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST - <font size="6" color="red">tEMed</font>';

$(document).ready( function () 
{
    
    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
        $(this).find("lastname").text() + ' (' +  
        $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   

})


/////////////////////////////////////// 
//           Patient Select
///////////////////////////////////////
function Result(sel)
{

  var pid_txt  = $("#PID option:selected" ).text();
  var pid_val  = $("#PID option:selected" ).val();
    
  var cid_txt  = $("#CID option:selected" ).text();
  var cid_val  = $("#CID option:selected" ).val();
        
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + pid_txt + ' (' + cid_txt + ')</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getpatientdocuments.php?token=' + key + 
   '&patientId=' + pid_val + '&categoryId=' + cid_val +  
   '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');

  patientDocsData (pid_val, pid_txt, cid_val, cid_txt); 
  fetch(pid_val, pid_txt, cid_val, cid_txt);
   
}


/////////////////////////////////////// 
//       Get Patient Documents
///////////////////////////////////////
function fetch(pid_val, pid_txt, cid_val, cid_txt) 
{
    setTimeout ( function() 
    {
      patintDocsData(pid_val, pid_txt, cid_val, cid_txt);
      fetch(pid_val, pid_txt, cid_val, cid_txt);
    }, timeout);
}


/*----------------------------
     Patient Docs Data
----------------------------*/
function patientDocsData (pid_val, pid_txt, cid_val, cid_txt) 
{    

    // 2. AJAX - DOCUMENTS
    var url_doc = "";
    
    $.ajax ({
    
    url: server + "/openemr/api/getpatientdocuments.php?token=" + key + 
    "&patientId=" + pid_val + "&categoryId=" + cid_val, 
    
    dataType: "xml",
    type: "GET",
     
    cache: false,    
    contentType: "application/x-www-form-urlencoded",  
    //global: true,
    //ifModified: false,
     
    
    success: function (data) 
    {
      
      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();
      $("#NO_RESULT").children().remove();

      // Status Reason
      $(data).find("patientdocuments").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })
      
      // Request API OEMR - XML Parsing
      $(data).find("document").each ( function() {
                 
      if (
            $(this).find("mimetype").text() == "image/png"  || 
            $(this).find("mimetype").text() == "image/jpeg" ||
            $(this).find("mimetype").text() == "image/application/octet-stream"
            //$(this).find("mimetype").text() == "application/octet-stream"
         ) 
      
      {
        url_doc = '<li><b>URL:</b> ' + '<a href=' + "" + '>' + '</a><img src="' + 
        $(this).find("url").text() + '"></a></li>';   
      }
      
      else
      
      {
        url_doc = '<li><b>URL:</b><a href = ' +  $(this).find("url").text() + ' target = "_blank">' + 
        $(this).find("url").text()  + '</a></li>';  
      }

      var info = 
      '<h3 id="title">' +  pid_txt +  '&nbsp; &nbsp; Document ID: ' + $(this).find("id").text() + '</h3>' + 
      '<li><b>Date:</b> ' + $(this).find("date").text() + '</li>' +
      '<li><b>Size:</b> ' + $(this).find("size").text() + '</li>' +
      
      url_doc +
      
      '<li><b>DOC DATE:</b> ' + $(this).find("docdate").text() + '</li>' +
      '<li><b>Mimetype:</b> ' + $(this).find("mimetype").text() + '</li>' +
      
      '<li><b>Category ID:</b> ' + $(this).find("category_id").text() + ' (' +
      CatName($(this).find("category_id").text()) + ')</li>' + '<hr><br>'
      
      $("#OEMR").append(info);
           
      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     // ADD NOT_FOUND
     $(data).find("patientdocuments").each ( function() 
     {
        status = $(this).find("status").text();    
        //alert (status);  
        if (status != '0') {$("#NO_RESULT").html('<div style="margin-left:40px"><img src="images/no-result.png" alt="Not Result"></div>')};
     })

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })
}


function CatName(id_cat) 
{

  switch (id_cat)
  {
    case "2":  return('Lab Report');
                break;
    case "3":  return('Medical Record');
                break;
    case "5":  return('Patient ID card');
                break;
    case "10": return('Patient Photograph');
                break;
    case "11": return('CCR');
                break;
    case "12": return('CCD');
                break;
    default:
                return ("No Category");
                break;
  }

}

/*--------------------------------------------------------------------
//Get Patients
function GetPatients () 
{    
    
    // Get All Patients
    var url = 'http://sgiman.com.ua/openemr/api/getallpatients.php?token=df19b7027c8cab07db1e9eef0566e1c9';
    var request = new XMLHttpRequest();
    
    request.open("GET", url, false);
    request.send();

    var xml = request.responseXML;
    
    return (xml);
    
}
--------------------------------------------------------------------*/
