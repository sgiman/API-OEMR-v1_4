/*************************************************************************************************
 *   020_getpatientrecord.js
 *
 *   Get Patient Record (ALL RECORDS)
 *   Api fetch complete patient record 
 *
 *   http://sgiman.com.ua/openemr/api/getpatientrecord.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientID=3
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientID=3 
 *
 *   FULL PATIENT EMR/EHR-REPORT:
 *          
 *      *1.  DEMOGRAHICS 
 *      *2.  INSURANCE LIST 
 *      *3.  HISTORY 
 *      *4.  PROBLEM LIST 
 *      *5.  MEDICATION LIST 
 *      *6.  ALLEGRY LIST 
 *      *7.  VITAL LIST
 *      *8.  DENTAL LIST 
 *      *9.  SURGERY LIST 
 *      *10. NOTE LIST 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.5                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {
        // Remove elements 
        if ($(this) != '') $("#PID").children().remove();   

        // PATIENTS (Select:Options)
        $("#PID").append('<option selected value="0">NONE</option>');
        $(data).find("Patient").each( function() 
        {
          var pat =
          '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
          $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
          $("#PID").append(pat);
   
        })

    }

    })   

});


/*-------------------------
      Patient Select 
------------------------- */
function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getpatientrecord.php?token=' + key +'&patientID='+ g_pid + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  RecordData (g_pid);
  fetch (g_pid);
   
}

/**********************************
*   Get Patient Record
*
*   1.  DEMOGRAHICS 
*   2.  INSURANCES 
*   3.  HISTORY 
*   4.  PROBLEM 
*   5.  MEDICATION
*   6.  ALLEGRY 
*   7.  VITALS
*   8.  DENTAL 
*   9.  SURGERY 
*   10. NOTES 
*
************************************/
function fetch(pid) {
    setTimeout ( function() 
    {
      RecordData (pid);
      fetch (pid);
    }, timeout);
}


function RecordData (pid) 
{
    
    // 2. AJAX - PATIENT ALL RECORDS
 
    $.ajax ({
  
    url: server + "/openemr/api/getpatientrecord.php?token=" + key + "&patientID=" + pid,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#DEMOGRAHICS").children().remove();   
      if ($(this) != '') $("#INSURANCES").children().remove();   
      if ($(this) != '') $("#HISTORY").children().remove();   
      if ($(this) != '') $("#PROBLEM").children().remove();   
      if ($(this) != '') $("#MEDICATION").children().remove();   
      if ($(this) != '') $("#ALLEGRY").children().remove();   
      if ($(this) != '') $("#VITALS").children().remove();   
      if ($(this) != '') $("#DENTAL").children().remove();   
      if ($(this) != '') $("#SURGERY").children().remove();   
      if ($(this) != '') $("#NOTES").children().remove();   
      if ($(this) != '') $("#OEMR").children().remove();   

      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("PatientList").text ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' +  
          $(this).find("reason").text().slice(0,33) + '</h2>'; 
          $('#Status').html(status);      
      })

/*---------------------------- RECORDS ----------------------------------*/


      ////////////////////////////////////////////// 
      //          1. D E M O G R A H I C S 
      //////////////////////////////////////////////
     // var title = '<h1 id="title">1. DEMOGRAHICS</h1>';
     // $("#DEMOGRAHICS").append(title);

      $(data).find("demographics").each ( function() {

       var info_demographics = 

      '<li><h2>Patient: <font color="#427DB7">' + 
      $(this).find("title").text() + ' ' + 
      $(this).find("fname").text() + ' ' + 
      $(this).find("mname").text() + ' ' +
      $(this).find("lname").text() + '</font></h2></li>' +

      '<li><b><font size=4>ID: ' + $(this).find("id").text() + '</font></b></li><br>' + 

      '<li><b>PATIENT ID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>PUBLISHED ID: </b>' + $(this).find("pubpid").text() + '</li>' +
      '<li><b>Language: </b>' + $(this).find("language").text() + '</li>' +
      '<li><b>Financial: </b>' + $(this).find("financial").text() + '</li>' +
      '<li><b>DOB: </b>' + $(this).find("DOB").text() + '</li>' +
      '<li><b>Street: </b>' + $(this).find("street").text() + '</li>' +
      '<li><b>Postal Code: </b>' + $(this).find("postalcode").text() + '</li>' +
      '<li><b>City: </b>' + $(this).find("city").text() + '</li>' +
      '<li><b>State: </b>' + $(this).find("state").text() + '</li>' +
      '<li><b>Country Code: </b>' + $(this).find("countrycode").text() + '</li>' +
      '<li><b>Drivers License: </b>' + $(this).find("driverslicense").text() + '</li>' +
      '<li><b>SS: </b>' + $(this).find("ss").text() + '</li>' +
      '<li><b>Occupation: </b>' + $(this).find("occupation").text() + '</li>' +

      '<br><li><b>Phone Home: </b>' + $(this).find("phonehome").text() + '</li>' +
      '<li><b>Phone Biz: </b>' + $(this).find("phonebiz").text() + '</li>' +
      '<li><b>Phone Contact: </b>' + $(this).find("phonecontact").text() + '</li>' +
      '<li><b>Phone Cell: </b>' + $(this).find("phonecell").text() + '</li><br>' +

      '<li><b>Pharmacy ID: </b>' + $(this).find("pharmacyid").text() + '</li>' +
      '<li><b>Status: </b>' + $(this).find("status").text() + '</li>' +
      '<li><b>Contact Relationship: </b>' + $(this).find("contactrelationship").text() + '</li>' +
      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>Gender: </b>' + $(this).find("sex").text() + '</li>' +
      '<li><b>Referrer: </b>' + $(this).find("referrer").text() + '</li>' +
      '<li><b>Referrer ID: </b>' + $(this).find("referrerID").text() + '</li>' +
      '<li><b>Provider ID: </b>' + $(this).find("providerID").text() + '</li>' +
      '<li><b>Ref Provider ID: </b>' + $(this).find("refproviderID").text() + '</li>' +
      '<li><b>Email: </b>' + $(this).find("email").text() + '</li>' +
      '<li><b>Email Direct: </b>' + $(this).find("emaildirect").text() + '</li>' +

      '<br><li><b>Ethnoracial: </b>' + $(this).find("ethnoracial").text() + '</li>' +
      '<li><b>Race: </b>' + $(this).find("race").text() + '</li>' +
      '<li><b>Ethnicity: </b>' + $(this).find("ethnicity").text() + '</li>' +
      '<li><b>Interpretter: </b>' + $(this).find("interpretter").text() + '</li>' +
      '<li><b>Migrant Seasonal: </b>' + $(this).find("migrantseasonal").text() + '</li>' +
      '<li><b>Family Size: </b>' + $(this).find("familysize").text() + '</li>' +
      '<li><b>Monthly Income: </b>' + $(this).find("monthlyincome").text() + '</li>' +
      '<li><b>Homeless: </b>' + $(this).find("homeless").text() + '</li>' +
      '<li><b>Homeless Financial Review: </b>' + $(this).find("homelessfinancialreview").text() + '</li>' +

      '<li><b>Generic Name 1: </b>' + 
      $(this).find("genericname").text()  + ' ' + 
      $(this).find("genericval").text() + '</li>' +

      '<li><b>Generic Name 2: </b>' + 
      $(this).find("genericname").text() + ' ' + 
      $(this).find("genericval").text() + '</li>' +

      '<br><li><b>HIPAA Mail: </b>' + $(this).find("hipaamail").text() + '</li>' +
      '<li><b>HIPAA Voice: </b>' + $(this).find("hipaavoice").text() + '</li>' +
      '<li><b>HIPAA Notice: </b>' + $(this).find("hipaanotice").text() + '</li>' +
      '<li><b>HIPAA Message: </b>' + $(this).find("hipaamessage").text() + '</li>' +
      '<li><b>HIPAA Allow SMS: </b>' + $(this).find("hipaaallowsms").text() + '</li>' +
      '<li><b>HIPAA Allow Email: </b>' + $(this).find("hipaaallowemail").text() + '</li>' +

      '<br><li><b>Squad: </b>' + $(this).find("squad").text() + '</li>' +
      '<li><b>Fitness: </b>' + $(this).find("fitness").text() + '</li>' +
      '<li><b>Referralsource: </b>' + $(this).find("referralsource").text() + '</li>' +
      '<li><b>Price Level: </b>' + $(this).find("pricelevel").text() + '</li>' +
      '<li><b>Reg Date: </b>' + $(this).find("regdate").text() + '</li>' +
      '<li><b>Contrastart: </b>' + $(this).find("contrastart").text() + '</li>' +
      '<li><b>Completedad: </b>' + $(this).find("completedad").text() + '</li>' +
      '<li><b>Adreviewed: </b>' + $(this).find("adreviewed").text() + '</li>' +
      '<li><b>VFC: </b>' + $(this).find("vfc").text() + '</li>' +
      '<li><b>Mothers Name: </b>' + $(this).find("mothersname").text() + '</li>' +
      '<li><b>Guardians Name: </b>' + $(this).find("guardiansname").text() + '</li>' +
      '<br><li><b>Allow Imm Reg Use: </b>' + $(this).find("allowimmreguse").text() + '</li>' +
      '<li><b>Allow Imm Info Share: </b>' + $(this).find("allowimminfoshare").text() + '</li>' +
      '<li><b>Allow Health Info Ex: </b>' + $(this).find("allowhealthinfoex").text() + '</li>' +
      '<li><b>Allow Patient Portal: </b>' + $(this).find("allowpatientportal").text() + '</li>' +

      '<br><li><b>Deceased Date: </b>' + $(this).find("deceaseddate").text() + '</li>' +
      '<li><b>Deceased Reason: </b>' + $(this).find("deceasedreason").text() + '</li>' +
      '<li><b>SOAP Import Status: </b>' + $(this).find("soapimportstatus").text() + '</li>' +
      '<li><b>CMS Portal Login: </b>' + $(this).find("cmsportallogin").text() + '</li>' +
      '<li><b>DOBTS: </b>' + $(this).find("DOBTS").text() + '</li>' +
      '<li><b>Ethnicity Value: </b>' + $(this).find("ethnicityvalue").text() + '</li>' +

      '<br><li><b>Profile Image:</b><br> ' + 
      '<a href=' + "" + '>' + '</a><img src="' + $(this).find("profileimage").text() + '"></a></li><hr><br>';   

       $("#DEMOGRAHICS").append(info_demographics);

       }) // -- End Demographics -- 
       

      ////////////////////////////////////////////// 
      //     2. I N S U R A N C E S   L I S T 
      ////////////////////////////////////////////// 
      var i=0;
      var name_i = ['Primary', 'Secondary', 'Tertiary']; 
      
      //var title = '<br><h1 id="title">2. INSURANCES</h1>'; 
      //$("#INSURANCES").append(title);

      $(data).find("insuranceitem").each ( function() {
      
      var info_insurancelist =    

      '<h2 id="title-gray"><font color="Crimson"> INSURANCE' + ' ' + (++i) +  
      ' (' + name_i[i-1] + ')' + '</font></h2>' + 

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></li><br>' +
      '<li><b>Provider Name: ' + '<font color="#427DB7" size=4>' + $(this).find("providername").text() + '</font></b></li>' + 
      '<li><b>Plan Name: ' + '<font color="#427DB7" size=4 >' + $(this).find("planname").text() + '</font></b></li>' +
      '<li><b>Provider: ' + $(this).find("provider").text() + '</b></li>' +
      '<li><b>Policy Number: </b>' + $(this).find("policynumber").text() + '</li>' +
      '<li><b>Group Number: </b>' + $(this).find("groupnumber").text() + '</li>' +

      '<li><b>Subscriber Name: ' + '<font color="#427DB7" size=4 >' + 
      $(this).find("subscriberlname").text() + ' ' +
      $(this).find("subscribermname").text() + ' ' +
      $(this).find("subscriberfname").text() + '</font></b></li>' +
    
      '<li><b>Subscriber Relationship: </b>' + $(this).find("subscriberrelationship").text() + '</li>' +
      '<li><b>Subscriber SS: </b>' + $(this).find("subscriberss").text() + '</li>' +
      '<li><b>Subscriber DOB: </b>' + $(this).find("subscriberDOB").text() + '</li>' +
      '<li><b>Subscriber Street: </b>' + $(this).find("subscriberstreet").text() + '</li>' +
      '<li><b>subscriber Postalcode: </b>' + $(this).find("subscriberpostalcode").text() + '</li>' +
      '<li><b>subscriber City: </b>' + $(this).find("subscribercity").text() + '</li>' +
      '<li><b>subscriber State: </b>' + $(this).find("subscriberstate").text() + '</li>' +
      '<li><b>subscriber Country: </b>' + $(this).find("subscribercountry").text() + '</li>' +
      '<li><b>subscriber Phone: </b>' + $(this).find("subscriberphone").text() + '</li>' +
      '<li><b>subscriber Employer: </b>' + $(this).find("subscriberemployer").text() + '</li>' +
      '<li><b>subscriber Employer Street: </b>' + $(this).find("subscriberemployerstreet").text() + '</li>' +
      '<li><b>subscriber Employer Postalcode: </b>' + $(this).find("subscriberemployerpostalcode").text() + '</li>' +
      '<li><b>subscriber Employer State: </b>' + $(this).find("subscriberemployerstate").text() + '</li>' +
      '<li><b>subscriber Employer Country: </b>' + $(this).find("subscriberemployercountry").text() + '</li>' +
      '<li><b>subscriber Employer City: </b>' + $(this).find("subscriberemployercity").text() + '</li><br>' +
      '<li><font color="Crimson" size="4"><b>Copay: </b>' + $(this).find("copay").text() + '</font></li>' +
      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>Subscriber Sex: </b>' + $(this).find("subscribersex").text() + '</li>' +
      '<li><b>Accept Assignment: </b>' + $(this).find("acceptassignment").text() + '</li>' +
      '<li><b>Policy Type: </b>' + $(this).find("policytype").text() + '</li>' + '<hr><br>';

       $("#INSURANCES").append(info_insurancelist);

      }) // -- END INSURANCES-- 


      ////////////////////////////////////////////// 
      //             3. H I S T O R Y 
      ////////////////////////////////////////////// 
      //var title = '<br><h1 id="title">3. HISTORY</h1>';
      //$("#HISTORY").append(title);

      $(data).find("history").each ( function() {

      var info_history = 

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></li><br>' +

      '<li><b>Coffee: </b>' + $(this).find("coffee").text() + '</li>' +
      '<li><b>Tobacco: </b>' + $(this).find("tobacco").text() + '</li>' +
      '<li><b>Alcohol: </b>' + $(this).find("alcohol").text() + '</li>' +
      '<li><b>Sleep patterns: </b>' + $(this).find("sleeppatterns").text() + '</li>' +
      '<li><b>Exercise Patterns: </b>' + $(this).find("exercisepatterns").text() + '</li>' +
      '<li><b>Seat Beltuse: </b>' + $(this).find("seatbeltuse").text() + '</li>' +
      '<li><b>Counseling: </b>' + $(this).find("counseling").text() + '</li>' +
      '<li><b>Hazardous Activities: </b>' + $(this).find("hazardousactivities").text() + '</li>' +
      '<li><b>Recreational Drugs: </b>' + $(this).find("recreationaldrugs").text() + '</li>' +

//      '<br><li><b>Last Breast Exam: </b>' + $(this).find("lastbreastexam").text() + '</li>' +
//      '<li><b>Last Mammogram: </b>' + $(this).find("lastmammogram").text() + '</li>' +
//      '<li><b>Last Gynocological Exam: </b>' + $(this).find("lastgynocologicalexam").text() + '</li>' +
//      '<li><b>Last Rectal Exam: </b>' + $(this).find("lastrectalexam").text() + '</li>' +
//      '<li><b>Last Prostate Exam: </b>' + $(this).find("lastprostateexam").text() + '</li>' +
//      '<li><b>Last Physical Exam: </b>' + $(this).find("lastphysicalexam").text() + '</li>' +
//      '<li><b>Last Sigmoidos Copy Colonos Copy: </b>' + $(this).find("lastsigmoidoscopycolonoscopy").text() + '</li>' +
//      '<li><b>Last ECG: </b>' + $(this).find("lastecg").text() + '</li>' +
//      '<li><b>Last Cardiac Echo: </b>' + $(this).find("lastcardiacecho").text() + '</li>' +
//      '<li><b>Last Retinal: </b>' + $(this).find("lastretinal").text() + '</li>' +
//      '<li><b>Last Fluvax: </b>' + $(this).find("lastfluvax").text() + '</li>' +
//      '<li><b>Last Pneuvax: </b>' + $(this).find("lastpneuvax").text() + '</li>' +
//      '<li><b>Last LDL: </b>' + $(this).find("lastldl").text() + '</li>' +
//      '<li><b>Last Hemoglobin: </b>' + $(this).find("lasthemoglobin").text() + '</li>' +
//      '<li><b>Last PSA: </b>' + $(this).find("lastpsa").text() + '</li>' +
//      '<li><b>Last Exam Results: </b>' + $(this).find("lastexamresults").text() + '</li>' +

      '<br><li><b>History Mother: </b>' + $(this).find("historymother").text() + ' ' +
      $(this).find("dcmother").text() + '</li>' +
      
      '<li><b>History Father: </b>' + $(this).find("historyfather").text() + ' ' +
      $(this).find("dcfather").text() + '</li>' +
      
      '<li><b>History Siblings: </b>' + $(this).find("historysiblings").text() + ' ' +
      $(this).find("dcsiblings").text() + '</li>' +
      
      '<li><b>History Offspring: </b>' + $(this).find("historyoffspring").text()  + ' ' +
       $(this).find("dcoffspring").text() + '</li>' +
      
      '<li><b>History Spouse: </b>' + $(this).find("historyspouse").text()  + ' ' +
      $(this).find("dcspouse").text() + '</li>' +

      '<br><li><b>Relatives Cancer: </b>' + $(this).find("relativescancer").text() + '</li>' +
      '<li><b>Relatives Tuberculosis: </b>' + $(this).find("relativestuberculosis").text() + '</li>' +
      '<li><b>Relatives Diabetes: </b>' + $(this).find("relativesdiabetes").text() + '</li>' +
      '<li><b>Relatives Highblood Pressure: </b>' + $(this).find("relativeshighbloodpressure").text() + '</li>' +
      '<li><b>Relatives Heart Problems: </b>' + $(this).find("relativesheartproblems").text() + '</li>' +
      '<li><b>Relatives Heart Problems: </b>' + $(this).find("relativesheartproblems").text() + '</li>' +
      '<li><b>Relatives Stroke: </b>' + $(this).find("relativesstroke").text() + '</li>' +
      '<li><b>Relatives Epilepsy: </b>' + $(this).find("relativesepilepsy").text() + '</li>' +
      '<li><b>Relatives Mental Illness: </b>' + $(this).find("relativesmentalillness").text() + '</li>' +
      '<li><b>Relatives Suicide: </b>' + $(this).find("relativessuicide").text() + '</li>' +

//      '<br><li><b>Cataractsurgery: </b>' + $(this).find("cataractsurgery").text() + '</li>' +
//      '<li><b>Tonsillectomy: </b>' + $(this).find("tonsillectomy").text() + '</li>' +
//      '<li><b>Cholecystestomy: </b>' + $(this).find("cholecystestomy").text() + '</li>' +
//      '<li><b>Heartsurgery: </b>' + $(this).find("heartsurgery").text() + '</li>' +
//      '<li><b>Hysterectomy: </b>' + $(this).find("hysterectomy").text() + '</li>' +
//      '<li><b>Herniarepair: </b>' + $(this).find("herniarepair").text() + '</li>' +
//      '<li><b>Hipreplacement: </b>' + $(this).find("hipreplacement").text() + '</li>' +
//      '<li><b>Kneereplacement: </b>' + $(this).find("kneereplacement").text() + '</li>' +
//      '<li><b>Appendectomy: </b>' + $(this).find("appendectomy").text() + '</li>' + 

      '<br><li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>Additional History: </b>' + $(this).find("additionalhistory").text() + '</li>' +
      '<li><b>Exams: </b>' + $(this).find("exams").text() + '</li>' + '<hr><br>';

       $("#HISTORY").append(info_history);

      }) // -- END HISTORY -- 


      ////////////////////////////////////////////// 
      //        4. P R O B L E M   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<br><h1 id="title">4. PROBLEM</h1>';
      //$("#PROBLEM").append(title);
      
      $(data).find("problem").each ( function() {

      var info_problemlist =  

      '<li><b><font size=4 >ID: </b>' + $(this).find("id").text() + '</font></li><br>' +
      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>Type: </b>' + $(this).find("type").text() + '</li>' +
      '<li><b>Title: ' + '<font size=4 color="Crimson">' + $(this).find("title").text() + '</font></b></li>' +
      '<li><b>Begin Date: </b>' + $(this).find("begdate").text() + '</li>' +
      '<li><b>End Date: </b>' + $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date: </b>' + $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence: </b>' + $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification: </b>' + $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by: </b>' + $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info: </b>' + $(this).find("extrainfo").text() + '</li>' +      
      '<li><b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '</li>' +      
      '<li><b>Activity: </b>' + $(this).find("activity").text() + '</li>' +      
      '<li><b>Comments: </b>' + $(this).find("comments").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +      
      '<li><b>Group Name: </b>' + $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome: </b>' + $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination: </b>' + $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury ID: </b>' + $(this).find("reinjuryid").text() + '</li>' +      
      '<li><b>Injury Part: </b>' + $(this).find("injurypart").text() + '</li>' +
      '<li><b>injury Type: </b>' + $(this).find("injurytype").text() + '</li>' +
      '<li><b>injury Grade: </b>' + $(this).find("injurygrade").text() + '</li>' +
      '<li><b>Reaction: </b>' + $(this).find("reaction").text() + '</li>' +
      '<li><b>External All Ergy ID: </b>' + $(this).find("externalallergyid").text() + '</li>' +
      '<li><b>eRx Source: </b>' + $(this).find("erxsource").text() + '</li>' +
      '<li><b>eRx Uploaded: </b>' + $(this).find("erxuploaded").text() + '</li>' +   
      '<li><b>Modifydate: </b>' + $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title: </b>' + $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';

       $("#PROBLEM").append(info_problemlist);
            
      }) // -- END PROBLEM -- 


      ////////////////////////////////////////////// 
      //     5. M E D I C A T I O N   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<br><h1 id="title">5. MEDICATION (PROBLEM)</h1>';
      //$("#MEDICATION").append(title);

      $(data).find("medication").each ( function() {

      var info_medicationlist =  

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></li><br>' +

      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>Type: </b>' + $(this).find("type").text() + '</li>' +
      '<li><b><font color="Crimson" size=4 >Title: ' + $(this).find("title").text() + '</font></b></li>' +
      '<li><b>Begin Date: </b>' + $(this).find("begdate").text() + '</li>' +
      '<li><b>End date: </b>' + $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date: </b>' + $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence: </b>' + $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification: </b>' + $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by: </b>' + $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info: </b>' + $(this).find("extrainfo").text() + '</li>' +
      '<li><b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '</li>' +
      '<li><b>Activity: </b>' + $(this).find("activity").text() + '</li>' +
      '<li><b>Comments: </b>' + $(this).find("comments").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +
      '<li><b>Group Name: </b>' + $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome: </b>' + $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination: </b>' + $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury ID: </b>' + $(this).find("reinjuryid").text() + '</li>' +
      '<li><b>injury Part: </b>' + $(this).find("injurypart").text() + '</li>' +
      '<li><b>injury Type: </b>' + $(this).find("injurytype").text() + '</li>' +
      '<li><b>injury Grade: </b>' + $(this).find("injurygrade").text() + '</li>' +
      '<li><b>Reaction: </b>' + $(this).find("reaction").text() + '</li>' +
      '<li><b>External Allergy ID: </b>' + $(this).find("externalallergyid").text() + '</li>' +
      '<li><b>eRx source: </b>' + $(this).find("erxsource").text() + '</li>' +
      '<li><b>eRx Uploaded: </b>' + $(this).find("erxuploaded").text() + '</li>' +
      '<li><b>Modify Date: </b>' + $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title: </b>' + $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';

       $("#MEDICATION").append(info_medicationlist);

      }) // -- END MEDICATION -- 


      ////////////////////////////////////////////// 
      //        6. A L L E G R Y   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<br><h1 id="title">6. ALLERGY</h1>';
      //$("#ALLERGY").append(title);

      $(data).find("allergy").each ( function() {     
      
      var info_allergylist =  

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></li><br>' +

      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>Type: </b>' + $(this).find("type").text() + '</li>' +
      '<li><b><font color="Crimson" size=4 >Title: ' + $(this).find("title").text() + '</font></b></li>' +
      '<li><b>Begin Date: </b>' + $(this).find("begdate").text() + '</li>' +
      '<li><b>End Date: </b>' + $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date: </b>' + $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence: </b>' + $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification: </b>' + $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by: </b>' + $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info: </b>' + $(this).find("extrainfo").text() + '</li>' +
      '<li><b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '</li>' +
      '<li><b>Activity: </b>' + $(this).find("activity").text() + '</li>' +
      '<li><b>Comments: </b>' + $(this).find("comments").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +
      '<li><b>Group Name: </b>' + $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome: </b>' + $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination: </b>' + $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury ID: </b>' + $(this).find("reinjuryid").text() + '</li>' +
      '<li><b>Injury Part: </b>' + $(this).find("injurypart").text() + '</li>' +
      '<li><b>Injury Type: </b>' + $(this).find("injurytype").text() + '</li>' +
      '<li><b>Injury Grade: </b>' + $(this).find("injurygrade").text() + '</li>' +
      '<li><b>Reaction: </b>' + $(this).find("reaction").text() + '</li>' +
      '<li><b>External Allergy ID: </b>' + $(this).find("externalallergyid").text() + '</li>' +
      '<li><b>eRx Source: </b>' + $(this).find("erxsource").text() + '</li>' +
      '<li><b>eRx Uploaded: </b>' + $(this).find("erxuploaded").text() + '</li>' +
      '<li><b>Nodifydate: </b>' + $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title: </b>' + $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';

       $("#ALLEGRY").append(info_allergylist);      
      
      }) // -- END ALLERGY -- 


      ////////////////////////////////////////////// 
      //          7. V I T A L   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<br><h1 id="title">7. VITALS</h1>';
      //$("#VITALS").append(title);
      
      $(data).find("vitals").each ( function() {

      var info_vitalslist = 

      '<li><b><font color="Crimson" size=4>Vitals Date: </b>' + $(this).find("vitalsdate").text() + '</font></li><br>' +
 
      '<li><b>Weight (lbs): </b>' + $(this).find("weight").text() + '</li>' +
      '<li><b>Height (in): </b>' + $(this).find("height").text() + '</li>' +
      '<li><b>BP Systolic (mmHg): </b>' + $(this).find("bps").text() + '</li>' +      
      '<li><b>BP Diastolic (mmHg): </b>' + $(this).find("bpd").text() + '</li>' +      
      '<li><b>Pulse (per min): </b>' + $(this).find("pulse").text() + '</li>' +
      '<li><b>Respiration (per min): </b>' + $(this).find("respiration").text() + '</li>' +
      '<li><b>Temperature (F): </b>' + $(this).find("temperature").text() + '</li>' +
      '<li><b>Temp Location: </b>' + $(this).find("tempmethod").text() + '</li>' +
      '<li><b>Oxygen Saturation (%): </b>' + $(this).find("oxygensaturation").text() + '</li>' + 
      '<li><b>Waist Circumference (in): </b>' + $(this).find("waistcirc").text() + '</li>' +
      '<li><b>Head Circumference (in): </b>' + $(this).find("headcirc").text() + '</li>' +
      '<li><b><font color="Crimson" size=4>BMI (kg/m^2): </b>' + $(this).find("bmi").text() + '</font></li>' +
      '<li><b><font color="#427DB7" size=4>BMI Status (type): ' + $(this).find("bmistatus").text() + '</font></b></li>' +
      '<li><b>Vital Note: </b>' + $(this).find("vitalnote").text() + '</li>' + '<hr><br>';

      $("#VITALS").append(info_vitalslist);

      }) // -- END VITALS -- 

  
      ////////////////////////////////////////////// 
      //         8. D E N T A L   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<h2 id="title">8. DENTAL</h2>';
      //$("#DENTAL").append(title);

      $(data).find("dental").each ( function() {

      var info_dentallist =  

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></b></li><br>' +
      
      '<li><b>Type: </b>' + $(this).find("type").text() + '</li>' +
      '<li><b>Title: </b>' + $(this).find("title").text() + '</li>' +
      '<li><b>Begin Date: </b>' + $(this).find("begdate").text() + '</li>' +
      '<li><b>End Date: </b>' + $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date: </b>' + $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence: </b>' + $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification: </b>' + $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by: </b>' + $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info: </b>' + $(this).find("extrainfo").text() + '</li>' +
      '<li><b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '</li>' +
      '<li><b>Activity: </b>' + $(this).find("activity").text() + '</li>' +
      '<li><b>Comments: </b>' + $(this).find("comments").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +
      '<li><b>Group Name: </b>' + $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome: </b>' + $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination: </b>' + $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury ID: </b>' + $(this).find("reinjuryid").text() + '</li>' +
      '<li><b>Injury Part: </b>' + $(this).find("injurypart").text() + '</li>' +
      '<li><b>Injury Type: </b>' + $(this).find("injurytype").text() + '</li>' +
      '<li><b>Injury Grade: </b>' + $(this).find("injurygrade").text() + '</li>' +
      '<li><b>Reaction: </b>' + $(this).find("reaction").text() + '</li>' +
      '<li><b>External Allergy ID: </b>' + $(this).find("externalallergyid").text() + '</li>' +
      '<li><b>eRx Source: </b>' + $(this).find("erxsource").text() + '</li>' +
      '<li><b>eRx Uploaded: </b>' + $(this).find("erxuploaded").text() + '</li>' +
      '<li><b>Modify Date: </b>' + $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title: </b>' + $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';


      $("#DENTAL").append(info_dentallist);
      
      }) // -- END DENTAL -- 


      ////////////////////////////////////////////// 
      //        9. S U R G E R Y   L I S T 
      ////////////////////////////////////////////// 
      //var title = '<h2 id="title">9. SURGERY</h2>';
      //$("#SURGERY").append(title);

      $(data).find("surgery").each ( function() {

      var info_surgerylist =  

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></b></li><br>' +
      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +
      '<li><b>Type: </b>' + $(this).find("type").text() + '</li>' +
      '<li><b>Title: </b>' + $(this).find("title").text() + '</li>' +
      '<li><b>Begin Date: </b>' + $(this).find("begdate").text() + '</li>' +
      '<li><b>End Date: </b>' + $(this).find("enddate").text() + '</li>' +
      '<li><b>Return Date: </b>' + $(this).find("returndate").text() + '</li>' +
      '<li><b>Occurrence: </b>' + $(this).find("occurrence").text() + '</li>' +
      '<li><b>Classification: </b>' + $(this).find("classification").text() + '</li>' +
      '<li><b>Referred by: </b>' + $(this).find("referredby").text() + '</li>' +
      '<li><b>Extra Info: </b>' + $(this).find("extrainfo").text() + '</li>' +
      '<li><b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '</li>' +
      '<li><b>Activity: </b>' + $(this).find("activity").text() + '</li>' +
      '<li><b>Comments: </b>' + $(this).find("comments").text() + '</li>' +
      '<li><b>PID: </b>' + $(this).find("pid").text() + '</li>' +
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +
      '<li><b>Group Name: </b>' + $(this).find("groupname").text() + '</li>' +
      '<li><b>Outcome: </b>' + $(this).find("outcome").text() + '</li>' +
      '<li><b>Destination: </b>' + $(this).find("destination").text() + '</li>' +
      '<li><b>Reinjury ID: </b>' + $(this).find("reinjuryid").text() + '</li>' +
      '<li><b>Injury Part: </b>' + $(this).find("injurypart").text() + '</li>' +
      '<li><b>Injury Type: </b>' + $(this).find("injurytype").text() + '</li>' +
      '<li><b>Injury Grade: </b>' + $(this).find("injurygrade").text() + '</li>' +
      '<li><b>Reaction: </b>' + $(this).find("reaction").text() + '</li>' +
      '<li><b>External Allergy ID: </b>' + $(this).find("externalallergyid").text() + '</li>' +
      '<li><b>eRx source: </b>' + $(this).find("erxsource").text() + '</li>' +
      '<li><b>eRx Uploaded: </b>' + $(this).find("erxuploaded").text() + '</li>' +
      '<li><b>Modify Date: </b>' + $(this).find("modifydate").text() + '</li>' +
      '<li><b>Diagnosis Title: </b>' + $(this).find("diagnosistitle").text() + '</li>' + '<hr><br>';

      $("#SURGERY").append(info_surgerylist);

      }) // -- END SURGERY -- 


      ////////////////////////////////////////////// 
      //           10. N O T E   L I S T 
      //////////////////////////////////////////////      
      //var title = '<h2 id="title">10. NOTE</h2>';
      //$("#NOTES").append(title);
      
      $(data).find("note").each ( function() {

      var info_notelist =  

      '<li><b><font size=4>ID: </b>' + $(this).find("id").text() + '</font></b></li><br>' +
      
      '<li><b>Date: </b>' + $(this).find("date").text() + '</li>' +   
      '<li><b>User: </b>' + $(this).find("user").text() + '</li>' +
      '<li><b>Title: </b>' + $(this).find("title").text() + '</li>' +
      '<li><b>Message status: </b>' + $(this).find("messagestatus").text() + '</li>' +
      '<li><font color="Crimson"><b>Message: </b></font>' + $(this).find("body").text() + '</li>' + '<hr><br>';     
      
      $("#NOTES").append(info_notelist);

      }) // -- END NOTES -- 


/*---------------------------- END RECORDS ----------------------------------*/

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })

}
