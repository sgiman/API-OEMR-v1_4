/*************************************************************************************************
 *   020_getprescription.js
 *
 *   Get Prescription
 *   API is allowed to get patient prescription.
 *
 *   "http://sgiman.com.ua/openemr/api/getprescription.php?token=df19b7027c8cab07db1e9eef0566e1c9&visit_id=&patientID=10" 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *   visit_id = '' 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

//---------------------------------
//   Start Document (DOM)
//---------------------------------
$(document).ready( function () 
{
    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
        $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   

});

/////////////////////////////////////// 
//           Patient Select
///////////////////////////////////////

function PatientSel(sel)
{

  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getprescription.php?token=' + key + 
  '&visit_id=' + '&patientID=' + g_pid + '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  prescriptionData(g_pid, g_txt);
  fetch(g_pid, g_txt);

}

/////////////////////////////////////// 
//         Get prescription
///////////////////////////////////////

function fetch (pid, text) 
{
    
    setTimeout ( function() 
    {
      prescriptionData (pid, text);
      fetch (pid, text);
    }, timeout);

}

function prescriptionData (pid, name) 
{
    
    // 2. AJAX - prescription
    $.ajax ({
  
    url: server + '/openemr/api/getprescription.php?token=' + key + 
    '&visit_id=' + '&patientID=' + pid,    
    dataType: "xml",
    type: "GET",    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();
      $("#NO_RESULT").children().remove();

      // Status Reason
      $(data).find("PrescriptionList").text ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' +  
          $(this).find("status").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("prescription").each ( function() {
       
      var info = 
      
      '<br><h3 id="title">' + name + '&nbsp; &nbsp; ID: ' +  $(this).find("id").text() + '</h3>' +
      '<li><b>Patient ID:</b> ' + $(this).find("patient_id").text() + '</li>' +
      '<li><b>Filled by ID:</b> ' + $(this).find("filled_by_id").text() + '</li>' +
      '<li><b>Pharmacy ID:</b> ' + $(this).find("pharmacy_id").text() + '</li>' +
      '<li><b>Date Added:</b> ' + $(this).find("date_added").text() + '</li>' +
      '<li><b>Date Modified:</b> ' + $(this).find("date_modified").text() + '</li>' +
      // '<li><b>Encounter:</b> ' + $(this).find("encounter").text() + '</li>' +
      '<li><b>Start Date:</b> ' + $(this).find("start_date").text() + '</li>' +
      '<li><b><font size="5" color="Crimson">Drug:</b> ' + $(this).find("drug").text() + '</font></li>' +
      '<li><b>Drug ID:</b> ' + $(this).find("drug_id").text() + '</li>' +
      '<li><b>RXNORM Drug Code:</b> ' + $(this).find("rxnorm_drugcode").text() + '</li>' +
      
      '<li><font color="#427DB7" size="5"><b>Dosage:</b> ' + $(this).find("dosage").text() + 
       drug_units($(this).find("unit").text()) + ' ' +  
       drug_form($(this).find("form").text()) + ' ' +
       drug_interval($(this).find("interval").text()) + ' ' +  
       drug_route($(this).find("route").text()) + '</font></li>' +
      
      '<li><b>Quantity:</b> ' +  $(this).find("quantity").text() + '</li>' + 
      '<li><b>Size:</b> ' +  + $(this).find("size").text() + '</li>' + 
      
      //'<li><b>Unit:</b> ' + $(this).find("unit").text() + '</li>' +
      //'<li><b>Route:</b> ' + $(this).find("route").text() + '</li>' +
      //'<li><b>Interval:</b> ' + $(this).find("interval").text() + '</li>' +
      
      '<li><b>Substitute:</b> ' + $(this).find("substitute").text() + '</li>' +
      '<li><b>Refills:</b> ' + $(this).find("refills").text() + '</li>' +
      '<li><b>Per Refill:</b> ' + $(this).find("per_refill").text() + '</li>' +
      '<li><b>Filled Date:</b> ' + $(this).find("filled_date").text() + '</li>' +
      '<li><b>Medication:</b> ' + $(this).find("medication").text() + '</li>' +
      '<li><b>Note:</b> ' + $(this).find("note").text() + '</li>' +
      '<li><b>Active:</b> ' + $(this).find("active").text() + '</li>' +
      '<li><b>Datetime:</b> ' + $(this).find("datetime").text() + '</li>' +
      '<li><b>User:</b> ' + $(this).find("user").text() + '</li>' +
      '<li><b>Site:</b> ' + $(this).find("site").text() + '</li>' +
      '<li><b>Prescription GUID:</b> ' + $(this).find("prescriptionguid").text() + '</li>' +
      '<li><b>eRx Source:</b> ' + $(this).find("erx_source").text() + '</li>' +
      '<li><b>eRx Uploaded:</b> ' + $(this).find("erx_uploaded").text() + '</li>' +
      '<li><b>Drug Info eRx:</b> ' + $(this).find("drug_info_erx").text() + '</li>' +
 
      '<li><b>Provider ID:</b> ' + $(this).find("provider_id").text() + '</li>' +
      '<li><font size="5" color="#427DB7"><b>Provide:</b> ' + $(this).find("provider_fname").text() + ' ' +
        $(this).find("provider_mname").text() + ' ' + 
        $(this).find("provider_lname").text() + '</font></li>' + '<hr>';


     $("#OEMR").append(info);
       
     })
    
     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     // ADD NOT_FOUND
     $(data).find("PrescriptionList").each ( function() 
     {
        status = $(this).find("status").text();    
        //alert (status);  
        if (status != '0') {$("#NO_RESULT").html('<div style="margin-left:40px"><img src="images/no-result.png" alt="Not Result"></div>')};
     })

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}

/*--------------------------------------
     Prescription Option TItles    
---------------------------------------*/
// 1. Drug Units
function drug_units (units)
{
  var units_name;  
  switch (units) 
  {
    case "0":  
            units_name = "";
            break;                  

    case "1":
            units_name = "mg";
            break;                  

    case "2":
            units_name = "mg/1cc";
            break;                  

    case "3":
            units_name = "mg/2cc"; 
            break;                  
 
    case "4":
            units_name = "mg/3cc";
            break;                  
 
    case "5":
            units_name = "mg/4cc";
            break;                  
 
    case "6":
            units_name = "mg/5cc";
            break;                  

    case "7":
            units_name = "mcg";
            break;                  

    case "8":
            units_name = "grams";
            break;                  
  
    default: 
            units_name = "";
            break;                  
  }

  return units_name;

}


// 2. Drug Form
function drug_form (form)
{
  var form_name;  
  switch (form) 
  {
    case "0":  
            form_name = "";
            break;                  

    case "1":
            form_name = "suspension";
            break;                  

    case "10":
            form_name = "cream";
            break;                  

    case "11":
            form_name = "ointment";
            break;                  

    case "2":
            form_name = "tablet";
            break;                  

    case "3":
            form_name = "capsule";
            break;                  

    case "4":
            form_name = "solution";
            break;                  

    case "5":
            form_name = "tsp";
            break;                  

    case "6":
            form_name = "ml";
            break;                  

    case "7":
            form_name = "units";
            break;                  

    case "8":
            form_name = "inhalations";
            break;                  

    case "9":
            form_name = "gtts(drops)";
            break;                  

    default: 
            form_name = "";
            break;                  
  }

  return form_name;

}


// 3. Drug Route
function drug_route (route)
{
  var route_name;  
  switch (route) 
  {
    case "0":  
            route_name = "";
            break;                  

    case "1":
            route_name = "Per Oris";
            break;                  

    case "10":
            route_name = "IM";
            break;                  

    case "11":
            route_name = "IV";
            break;                  

    case "12":
            route_name = "Per Nostril";
            break;                  

    case "13":
            route_name = "Both Ears";
            break;                  

    case "14":
            route_name = "Right Ear";
            break;                  

    case "15":
            route_name = "Per Rectum";
            break;                  

    case "2":
            route_name = "To Skin";
            break;                  

    case "3":
            route_name = "To Affected Area";
            break;                  

    case "4":
            route_name = "Sublingual";
            break;                  

    case "5":
            route_name = "Sublingual";
            break;                  

    case "6":
            route_name = "OS";
            break;                  

    case "7":
            route_name = "OD";
            break;                  

    case "8":
            route_name = "OU";
            break;                  

    case "9":
            route_name = "SQ";
            break;                  

    default: 
            route_name = "";
            break;                  
  }

  return route_name;

}


// 4. Drug Interval
function drug_interval (interval)
{
  var interval_name;  
  switch (interval) 
  {
    case "0":  
            interval_name = "";
            break;                  

    case "1":
            interval_name = "b.i.d.";
            break;                  

    case "10":
            interval_name = "a.c.";
            break;                  

    case "11":
            interval_name = "p.c.";
            break;                  

    case "12":
            interval_name = "a.m.";
            break;                  

    case "13":
            interval_name = "p.m.";
            break;                  

    case "14":
            interval_name = "ante";
            break;                  

    case "15":
            interval_name = "h";
            break;                  

    case "16":
            interval_name = "h.s.";
            break;                  

    case "17":
            interval_name = "p.r.n.";
            break;                  

    case "18":
            interval_name = "stat";
            break;                  

    case "2":
            interval_name = "t.i.d.";
            break;                  

    case "3":
            interval_name = "q.i.d.";
            break;                  

    case "4":
            interval_name = "q.3h";
            break;                  

    case "5":
            interval_name = "q.4h";
            break;                  

    case "6":
            interval_name = "q.5h";
            break;                  

    case "7":
            interval_name = "q.6h";
            break;                  

    case "8":
            interval_name = "q.8h";
            break;                  

    case "9":
            interval_name = "q.d.";
            break;                  

    default: 
            interval_name = "";
            break;                  
            
  }

  return interval_name;

}
