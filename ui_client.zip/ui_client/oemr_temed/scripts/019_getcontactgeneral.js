/*************************************************************************************************
 *   019_getcontactgeneral.js
 *   
 *   Get Contact General
 *   API retrieve user all contacts
 *
 *   http://sgiman.com.ua/openemr/api/getcontactgeneral.php?token=df19b7027c8cab07db1e9eef0566e1c9 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'Retrieve user all general contacts - <font size="6" color="red">tEMed</font>';

$(document).ready( function () 
{ 
  
  // TITLE TEST
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

  // XML REQUEST
  $('#XML').html('<a href="' + server + '/openemr/api/getcontactgeneral.php?token=' + key + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  contactData();
  fetch();

});

/////////////////////////////////////// 
//        Get Contact General
///////////////////////////////////////

function fetch() {
    setTimeout ( function() 
    {
      contactData();
      fetch();
    }, timeout);
}

function contactData () 
{
    $.ajax ({
  
    url: server + "/openemr/api/getcontactgeneral.php?token=" + key,    
    dataType: "xml",
    type: "GET",    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("contacts").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("contact").each ( function() {

      
      var info = 
      '<h3 id="title">Provider: ' + '<font size=5>' + $(this).find("fname").text() + ' ' + 
      $(this).find("mname").text() + ' ' +  $(this).find("lname").text() + 
      
      ' (' +  $(this).find("organization").text() + ')</font></h3>' + 
      
      '<li><b>ID:</b> ' +  $(this).find("id").text() + '</li>' +
      '<li><b>Username:</b> ' +  $(this).find("username").text() + '</li>' +
      '<li><b>Password:</b> ' +  $(this).find("password").text() + '</li>' +      
      '<li><b>Authorized:</b> ' +  $(this).find("authorized").text() + '</li>' +
      '<li><b>Info:</b> ' +  $(this).find("info").text() + '</li>' +
      '<li><b>Source:</b> ' +  $(this).find("source").text() + '</li>' +    
      '<li><b>UPIN:</b> ' +  $(this).find("upin").text() + '</li>' +
      '<li><b>SEE AUTH:</b> ' +  $(this).find("see_auth").text() + '</li>' +
      '<li><b>Active:</b> ' +  $(this).find("active").text() + '</li>' +
      '<li><b>NPI:</b> ' +  $(this).find("npi").text() + '</li>' +
      '<li><b>Taxonomy:</b> ' +  $(this).find("taxonomy").text() + '</li>' +
      '<li><b>Specialty:</b> ' +  $(this).find("specialty").text() + '</li>' +
      '<li><b>Organization:</b> ' +  $(this).find("organization").text() + '</li>' +
      '<li><b>Valedictory:</b> ' +  $(this).find("valedictory").text() + '</li>' +
      '<li><b>Assistant:</b> ' +  $(this).find("assistant").text() + '</li>' +
      '<li><b>Email:</b> ' +  $(this).find("email").text() + '</li>' +
      
      '<li><font color="#427DB7" size="5"><b>URL:</b> <a href="' + $(this).find("url").text() + '">' + 
      $(this).find("url").text() + '</a></font></li>' +
      
      '<li><b>Street:</b> ' +  $(this).find("street").text() + ' , ' + 
      $(this).find("streetb").text() + '</li>' +
      
      '<li><b>City:</b> ' +  $(this).find("city").text() + '</li>' +
      '<li><b>State:</b> ' +  $(this).find("state").text() + '</li>' +
      '<li><b>ZIP:</b> ' +  $(this).find("zip").text() + '</li>' +
      '<li><b>Home Phone:</b> ' +  $(this).find("phone").text() + '</li>' +
      '<li><b>Work Phone 1:</b> ' +  $(this).find("phonew1").text() + '</li>' +
      '<li><b>Work Phone 2:</b> ' +  $(this).find("phonew2").text() + '</li>' +
      '<li><b>Phone Cell:</b> ' +  $(this).find("phonecell").text() + '</li>' +
      '<li><b>Fax:</b> ' +  $(this).find("fax").text() + '</li>' +
      '<li><b>Notes:</b> ' +  $(this).find("notes").text() + '</li><br>' +      
      
      '<li><b>Image Contact:</b> ' + 
      '<a href=' + "" + '>' + '</a><img src="' + $(this).find("image_url").text() + '"></a></li>' +  
      
      '<li><b>Image Title:</b> ' +  $(this).find("image_title").text() + '</li><hr><br>';
      
      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}
