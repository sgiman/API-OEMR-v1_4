/*************************************************************************************************
 *   008_getvisits.js
 *
 *   Get Visits
 *   API returns all list items related to any particular visit id
 *
 *   "http://sgiman.com.ua/openemr/api/getvisits.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10" 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  
    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
        $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   
  
});


/////////////////////////////////////// 
//         Patient Select
///////////////////////////////////////

function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getvisits.php?token=' + key + '&patientId=' + g_pid + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');
  
  visitsData(g_pid,g_txt);
  fetch(g_pid,g_txt);
   
}


/////////////////////////////////////// 
//            Get Visits
///////////////////////////////////////

function fetch(pid,txt) {
    setTimeout ( function() 
    {
      visitsData(pid,txt);
      fetch(pid,txt);
    }, timeout);
}


function visitsData (pid,txt) 
{
  
    // 2. AJAX - VISITS
    $.ajax ({
  
    url: server + "/openemr/api/getvisits.php?token=" + key + "&patientId=" + pid,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("PatientVisit").text ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' +  
          $(this).find("status").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("Visit").each ( function() {
       
       var info = 
      
      '<br><h3 id="title">' + txt + '&nbsp; &nbsp; ID: ' +  $(this).find("id").text() + '</h3>' +
      '<li><b><font size="4" color="#427DB7">Encounter (Visit ID) :</font></b> ' +  $(this).find("encounter").text() + '</li>' +
      '<li><b>Date:</b> ' +  $(this).find("date").text() + '</li>' +
      '<li><b>Reason: ' +  '<font size="4" color="Crimson">' + $(this).find("reason").text() + '</b></font></li>' +
      '<li><b>Facility:</b> ' +  $(this).find("facility").text() + '</li>' +
      '<li><b>Facility ID:</b> ' +  $(this).find("facility_id").text() + '</li>' +
      '<li><b>Patient ID:</b> ' +  $(this).find("pid").text() + '</li>' +
      '<li><b>On set Date:</b> ' +  $(this).find("onset_date").text() + '</li>' +
      '<li><b>Sensitivity:</b> ' +  $(this).find("sensitivity").text() + '</li>' +
      '<li><b>Billing Note:</b> ' +  $(this).find("billing_note").text() + '</li>' +
      '<li><b>PC CATID:</b> ' +  $(this).find("pc_catid").text() + '</li>' +
      '<li><b>Last Level Billed:</b> ' +  $(this).find("last_level_billed").text() + '</li>' +
      '<li><b>Last Level Closed:</b> ' +  $(this).find("last_level_closed").text() + '</li>' +
      '<li><b>Last STMT Date:</b> ' +  $(this).find("last_stmt_date").text() + '</li>' +
      '<li><b>STMT Count:</b> ' +  $(this).find("stmt_count").text() + '</li>' +
      '<li><b>Provider id:</b> ' +  $(this).find("provider_id").text() + '</li>' +
      '<li><b>Supervisor id:</b> ' +  $(this).find("supervisor_id").text() + '</li>' +
      '<li><b>Invoice Refno:</b> ' +  $(this).find("invoice_refno").text() + '</li>' +
      '<li><b>Referral Source:</b> ' +  $(this).find("referral_source").text() + '</li>' +
      '<li><b>Billing Facility:</b> ' +  $(this).find("billing_facility").text() + '</li>' +
      '<li><b>PC CATNAME:</b> ' +  $(this).find("pc_catname").text() + '</li>' +
      '<li><b>Billing Facility Name:</b> ' +  $(this).find("billing_facility_name").text() + '</li><br>' +
      '<li><b><font size="4" color="red">Subjective:</font></b> ' +  $(this).find("subjective").text() + '</li>' +
      '<li><b><font size="4" color="Chocolate">Objective:</font></b> ' +  $(this).find("objective").text() + '</li>' +
      '<li><b><font size="4" color="BlueViolet">Assessment:</font></b> ' +  $(this).find("assessment").text() + '</li>' +
      '<li><b><font size="4" color="blue">Plan:</font></b> ' +  $(this).find("plan").text() + '</li><br>';
       $("#OEMR").append(info);
       
       i = 0;  
       $(this).find("Issue").each ( function() 
       {   
          i=i+1;
          var info =
          
          '<li><b><font color="green">ISSUE' + i + ': </font></b><br>' +
          '<b>Type: </b>'  + $(this).find("type").text() + '<br> ' + 
          '<b>Title: </b>' + '<font size="4" color="Crimson">' + $(this).find("title").text() + '</font><br>' + 
          '<b>Begin Date: </b>' + $(this).find("begdate").text() + '<br>' + 
          '<b>Diagnosis: </b>' + $(this).find("diagnosis").text() + '<hr>'; 
          $("#OEMR").append(info);
       })
      
      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}

