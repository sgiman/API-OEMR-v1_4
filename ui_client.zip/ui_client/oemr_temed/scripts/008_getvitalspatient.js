/*************************************************************************************************
 *   007_getvitalspatient.js
 *
 *   Get Visits
 *   API is allowed to get patient all main vitals
 *   (with chart BMI) 
 *    
 *   "http://sgiman.com.ua/openemr/api/getvitalspatient.php?token=df19b7027c8cab07db1e9eef0566e1c9&patientId=10" 
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   patientId = 10 
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST';

$(document).ready( function () 
{

    // TITLE TEST
    $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

    // 1. AJAX - PATIENTS LIST
    $.ajax ({
  
    url: server + "/openemr/api/getallpatients.php?token=" + key,
    dataType: "xml",
    type: "GET",

    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#PID").children().remove();   

      // PATIENTS (Select:Options)
      $("#PID").append('<option selected value="0">NONE</option>');
      $(data).find("Patient").each( function() 
      {
        var pat =
        '<option value="' + $(this).find("pid").text() + '">' + $(this).find("firstname").text() + ' ' +  
        $(this).find("lastname").text() + ' (' +  $(this).find("pid").text() + ')</option>'; 
    
        $("#PID").append(pat);
   
      })

    }

    })   
  
    chart2points (0, 0, "NO DATA");

});


/////////////////////////////////////// 
//           Patient Select
///////////////////////////////////////
function PatientSel(sel)
{
  var g_pid = sel.options[sel.selectedIndex].value;
  var g_txt = sel.options[sel.selectedIndex].text;
      
  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');

  $('#XML').html('<a href="' + server + '/openemr/api/getvitalspatient.php?token=' + key + '&patientId=' + g_pid + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');



  vitpatData(g_pid, g_txt);
  fetch(g_pid, g_txt);
   
}


/////////////////////////////////////// 
//            Get Visits
///////////////////////////////////////
function fetch(pid, txt) {
    setTimeout ( function() 
    {
      vitpatData(pid,txt);
      fetch(pid,txt);
    }, timeout);
}


function vitpatData (pid,txt) 
{
  
    // 2. AJAX - VITALS PATIENTS
    $.ajax ({
  
    url: server + "/openemr/api/getvitalspatient.php?token=" + key + "&patientId=" + pid,
    dataType: "xml",
    type: "GET",    
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("PatientVitals").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })
     
      var n = 0;
      var bps = [];
      var bpd = [];
      var weight = [];
      var height = [];
      var waist_circ = [];
      var temperature = [];
      var pulse = [];
      var respiration = [];
      var oxygen_saturation = [];
      var BMI = new Array();

      $(data).find("Vital").each ( function() {
        $(this).find("id").text();      
       
        bps[n]                 = parseInt($(this).find("bps").text());
        bpd[n]                 = parseInt($(this).find("bpd").text());
        weight[n]              = parseFloat($(this).find("weight").text());
        height[n]              = parseFloat($(this).find("height").text()); 
        waist_circ[n]          = parseFloat($(this).find("waist_circ").text()); 
        temperature[n]         = parseFloat($(this).find("temperature").text()); 
        pulse[n]               = parseInt($(this).find("pulse").text()); 
        respiration[n]         = parseInt($(this).find("respiration").text()); 
        oxygen_saturation[n]   = parseInt($(this).find("oxygen_saturation").text()); 
        BMI[n]                 = parseFloat($(this).find("BMI").text());
        n = n + 1;     
      
      });

              
       var label = "BMI";
       switch (n) 
       {
              case 0:
                  chart2points (0, 0, "NO DATA");
                  break;

              case 1:
                  chart2points (0, 0, "NO DATA");
                  break;

              case 2:
                  chart2points (BMI[0], BMI[1], label);
                  break;
                  
              case 3:
                  chart3points (BMI[0], BMI[1], BMI[2], label);
                  break;
                  
              case 4:
                  chart4points (BMI[0], BMI[1], BMI[2], BMI[3], label);
                  break;
                  
              case 5:
                  chart5points (BMI[0], BMI[1], BMI[2], BMI[3], BMI[4], label);
                  break;
                  
              default:
                  chart2points (BMI[0], BMI[n], label);
                  break;
      }

      
      // Request API OEMR - XML Parsing
      $(data).find("Vital").each ( function() {
                  
       var info = 
       
      '<h3 id="title">' + txt + '&nbsp; &nbsp; Vitals ID: ' +  $(this).find("id").text() + '</h3>' +

      '<li><b>BP Systolic (mmHg):</b> ' +  $(this).find("bps").text() + '</li>' + 
      '<li><b>BP Diastolic (mmHg):</b> ' +  $(this).find("bpd").text() + '</li>' +
      '<li><b>Weight (lbs):</b> ' +  $(this).find("weight").text() + '</li>' +
      '<li><b>Height (in):</b> ' +  $(this).find("height").text() + '</li>' +
      '<li><b>Waist Circ (in):</b> ' +  $(this).find("waist_circ").text() + '</li>' +
      '<li><b>Temperature (F):</b> ' +  $(this).find("temperature").text() + '</li>' +
      '<li><b>Pulse (per/min):</b> ' +  $(this).find("pulse").text() + '</li>' +
      '<li><b>Respiration (per/min):</b> ' +  $(this).find("respiration").text() + '</li>' +
      '<li><b>Oxygen Saturation (%):</b> ' +  $(this).find("oxygen_saturation").text() + '</li>' +
      '<li><b><font size="4" color="red">BMI (kg/m^2):</font></b> ' +  $(this).find("BMI").text() + '</li>' + 
      '<li><b><font size="4" color="#427DB7" >BMI Status (Type): ' +  $(this).find("BMI_status").text() + '</font></b></li>' + '<hr><br>';         
     
      $("#OEMR").append(info);

      })
      
     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');
      
     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }
 
  })

}

/*=====================================================
                     LINE CHARTS
 ======================================================*/

// LiNE CHART - 2 POINTS 
function chart2points (p1, p2, vitals) 
{
    
    var chart = new CanvasJS.Chart("chartContainer", 
    {
			title: {
				text: vitals
			},
			
			axisX: {
				interval: 10
			},
		
			data: [{
				type: "line",
				showInLegend: true,
				name: "Visit/" + vitals,

				dataPoints: [
				  { x: 2, y: p2 },
				  { x: 1, y: p1 },

				]
		
			}]
		
		});
		
		chart.render();
}


// LiNE CHART - 3 POINTS 
function chart3points (p1, p2, p3, vitals)
{
    var chart = new CanvasJS.Chart("chartContainer", 
    {
			title: {
				text: vitals
			},
		
			axisX: {
				interval: 10
			},
		
			data: [{
				type: "line",
				showInLegend: true,
				name: "Visit/" + vitals,

				dataPoints: [
				  { x: 3, y: p3 },
				  { x: 2, y: p2 },
				  { x: 1, y: p1 },
				]
		
			}]
		
		});
		
		chart.render();
}


// LiNE CHART - 4 POINTS 
function chart4points (p1, p2, p3, p4, s)
{
    var chart = new CanvasJS.Chart("chartContainer", 
    {
			title: {
				text: vitals
			},
		
			axisX: {
				interval: 10
			},
		
			data: [{
				type: "line",
				showInLegend: true,
				name: "Visit/" + vitals,

				dataPoints: [
				  { x: 4, y: p4 },
				  { x: 3, y: p3 },
				  { x: 2, y: p2 },
				  { x: 1, y: p1 },
				]
		
			}]
		
		});
		
		chart.render();
}


// LiNE CHART - 5 POINTS 
function chart5points (p1, p2, p3, p4, p5, vitals)
{
    var chart = new CanvasJS.Chart("chartContainer", 
    {
			title: {
				text: vitals
			},
		
			axisX: {
				interval: 10
			},
		
			data: [{
				type: "line",
				showInLegend: true,
				name: "Visit/" + vitals,

				dataPoints: [
				  { x: 5, y: p5 },
				  { x: 4, y: p4 },
				  { x: 3, y: p3 },
				  { x: 2, y: p2 },
				  { x: 1, y: p1 },
				]
		
			}]
		
		});
		
		chart.render();
}
