/*************************************************************************************************
 *   015_getmessages.js
 *
 *   Get Messages
 *   API returns all messages applying particular filters on them
 *
 *   http://sgiman.com.ua/openemr/api/getmessages.php?token=df19b7027c8cab07db1e9eef0566e1c9
 *
 *   For testing - login is disable!
 *   token = df19b7027c8cab07db1e9eef0566e1c9 
 *   
 *
 *   OpenEMR 4.2.x     
 *   http://www.open-emr.org
 *   API OEMR version 1.4                          
 *   Writing by sgiman, 2016 
 *
 *************************************************************************************************/
var key = "df19b7027c8cab07db1e9eef0566e1c9"; //login=admin, password=admin - only for testing
var timeout = 1000000;
var server = "http://sgiman.com.ua";

var g_txt = 'TEST - <font size="6" color="red">tEMed</font>';

$(document).ready( function () 
{

  $('#Name').html('<h1> &nbsp; .... &nbsp;' + g_txt + '</h1>');
  $('#XML').html('<a href="' + server + '/openemr/api/getmessages.php?token=' + key + 
  '"><img align="right" src="images/2000px-Xml_logo5.png" alt="XML"></a>');

  msgData();
  fetch();

});


/////////////////////////////////////// 
//            Get Messages
///////////////////////////////////////

function fetch() {
    setTimeout ( function() 
    {
      msgData();
      fetch();
    }, timeout);
}


function msgData () 
{
    $.ajax ({
  
    url: server + "/openemr/api/getmessages.php?token=" + key,
    dataType: "xml",
    type: "GET",
    success: function (data) 
    {

      // Remove elements 
      if ($(this) != '') $("#OEMR").children().remove();   
      $("#LOAD").children().remove();
      $("#to-top").children().remove();

      // Status Reason
      $(data).find("Messages").each ( function() 
      {
          var  status = '<h2><span class="BlueText">STATUS REASON: <\span>' + 
          $(this).find("reason").text() + '</h2>'; 
          $('#Status').html(status);      
      })

      // Request API OEMR - XML Parsing
      $(data).find("Message").each ( function() {
      
      var info = 
     
      '<h3>ID: ' +  $(this).find("id").text() + '</h3>' +
      '<li><b>User:</b> ' +  $(this).find("user").text() + '</li>' + 
      '<li><b>Patient ID:</b> ' +  $(this).find("pid").text() + '</li>' +
      '<li><b>Title:</b> ' +  $(this).find("title").text() + '</li>' +
      '<li><b>Date:</b> ' +  $(this).find("date").text() + '</li>' +
      '<li><b><font size="4" color="red">Message:</font></b> ' +  $(this).find("body").text() + '</li>' +
      '<li><b>Message Status:</b> ' +  $(this).find("message_status").text() + '</li>' +
      '<li><b>User:</b> ' +  $(this).find("users_fname").text() + ' ' +
      $(this).find("users_lname").text() + '</li>' +
      '<li><b>Patient:</b> ' +  $(this).find("patient_data_fname").text() + ' ' +
      $(this).find("patient_data_lname").text() + '</li>' + '<hr><br>';

      $("#OEMR").append(info);

      })

     // Button "TOP"  
     $("#OEMR").append('<a href="#"><span><img src="images/Top_Arror_Green_Small.png" alt="To Top"></span></a><br><br>');

     },
     
     // ERROR SQL Request from server
     error:function (xhr, ajaxOptions, thrownError){
     alert(xhr.status);
     alert(thrownError);
     }

  })


}
