<?php
/**
 * api/deleteprescription.php delete patient prescription.
 *
 * API is allowed to delete patient's prescription.
 * 
 * @package OpenEMR
 * @link    http://www.open-emr.org
 * API OEMR version 1.4
 * Modified by sgiman, 2016
 */
header("Content-Type:text/xml");
header("Access-Control-Allow-Origin: *");

$ignoreAuth = true;
require_once('classes.php');

$xml_string = "";
$xml_string = "<prescription>";

$token = $_GET['token'];
$id = $_GET['id'];


if ($userId = validateToken($token)) {
    $user = getUsername($userId);
    
    $acl_allow = acl_check('admin', 'super', $user);
    if ($acl_allow) {
        $strQuery = "DELETE FROM `prescriptions` WHERE id = ?";
        $result = sqlStatement($strQuery, array($id));

        if ($result) {
            $xml_string .= "<status>0</status>";
            $xml_string .= "<reason>The Patient prescription has been deleted</reason>";
        } else {
            $xml_string .= "<status>-1</status>";
            $xml_string .= "<reason>ERROR: Sorry, there was an error processing your data. Please re-submit the information again.</reason>";
        }
    } else {
        $xml_string .= "<status>-2</status>\n";
        $xml_string .= "<reason>You are not Authorized to perform this action</reason>\n";
    }
} else {
    $xml_string .= "<status>-2</status>";
    $xml_string .= "<reason>Invalid Token</reason>";
}

$xml_string .= "</prescription>";
echo $xml_string;
?>